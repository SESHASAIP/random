import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "neutral",
  children,
}: {
  className?: string;
  tone?: "neutral" | "pass" | "fail" | "marginal" | "accent";
  children: ReactNode;
}) {
  const tones = {
    neutral: "bg-fg/6 text-muted",
    pass: "bg-pass/12 text-pass",
    fail: "bg-fail/12 text-fail",
    marginal: "bg-marginal/12 text-marginal",
    accent: "bg-accent/10 text-accent",
  } as const;
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
