import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/** Render `Nu = 0.023 · Re^{0.8} · Pr^{0.4}` with real superscripts. */
export function EquationHero({ text, className }: { text: string; className?: string }) {
  const parts = text.split("=");
  const lhs = parts[0]?.trim() ?? "";
  const rhs = parts.slice(1).join("=").trim();
  return (
    <p
      className={cn(
        "font-display text-[1.65rem] leading-snug tracking-tight text-fg sm:text-4xl",
        className,
      )}
    >
      <span>{lhs}</span>
      <span className="mx-3 text-muted">=</span>
      <span>{renderPretty(rhs)}</span>
    </p>
  );
}

export function renderPretty(input: string): ReactNode[] {
  const tokens = input.split(/(\s·\s|·|\s)/);
  return tokens.map((tok, i) => {
    if (tok === "·" || tok === " · ") {
      return (
        <span key={i} className="mx-1 text-muted">
          ·
        </span>
      );
    }
    const sup = tok.match(/^(.*?)\^\{([^}]+)\}$/);
    if (sup) {
      return (
        <span key={i}>
          {sup[1]}
          <sup className="font-sans text-[0.55em] tracking-normal">{sup[2]}</sup>
        </span>
      );
    }
    const sup2 = tok.match(/^(.*?)\^([0-9.eE+-]+)$/);
    if (sup2) {
      return (
        <span key={i}>
          {sup2[1]}
          <sup className="font-sans text-[0.55em] tracking-normal">{sup2[2]}</sup>
        </span>
      );
    }
    if (tok.endsWith("²")) {
      return (
        <span key={i}>
          {tok.slice(0, -1)}
          <sup className="font-sans text-[0.55em]">2</sup>
        </span>
      );
    }
    return <span key={i}>{tok}</span>;
  });
}

export function MonoEq({ children }: { children: string }) {
  return <code className="font-mono text-[13px] leading-relaxed text-fg">{renderPretty(children)}</code>;
}
