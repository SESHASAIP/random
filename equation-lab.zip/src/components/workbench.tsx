import { useEffect, useMemo, useRef, useState } from "react";
import {
  Beaker,
  BookOpen,
  ChevronDown,
  CircleAlert,
  Download,
  Loader2,
  PencilLine,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EquationHero, MonoEq } from "@/components/equation-view";
import { ParetoChart, ResidualChart } from "@/components/charts";
import { Methodology } from "@/components/methodology";
import { cn } from "@/lib/utils";
import {
  configToYaml,
  defaultConfig,
  generateAdditive,
  generateNoise,
  generatePowerLaw,
  generateTiny,
  previewScreenAndTransforms,
  runPipeline,
  tableFromCsv,
  scoreUserExpression,
  exampleFor,
  probePysr,
  setJuliaProbe,
  describeEngine,
} from "@/lib/pipeline";
import type {
  DataTable,
  DatasetKind,
  EngineBackend,
  PipelineConfig,
  PipelineResult,
  Progress,
  ScreeningReport,
  TransformSpec,
  UserScore,
} from "@/lib/pipeline";

const DATASETS: { id: DatasetKind; title: string; blurb: string }[] = [
  {
    id: "heat",
    title: "Dittus–Boelter",
    blurb: "Known Nu = 0.023·Re^{0.8}·Pr^{0.4}, four decoys, 5% noise.",
  },
  {
    id: "additive",
    title: "Additive identity",
    blurb: "y = 2.5·x0 + x1·x2, 300 clean rows. Engine acceptance case.",
  },
  {
    id: "noise",
    title: "Pure noise",
    blurb: "Target is Gaussian. The gate must FAIL and refuse an equation.",
  },
  {
    id: "tiny",
    title: "50 rows",
    blurb: "Same physics, undersized. Screening hard-stops.",
  },
  {
    id: "csv",
    title: "Upload CSV",
    blurb: "Numeric CSV. Last column is the target. Sample file linked below.",
  },
];

function loadDataset(kind: DatasetKind, csv?: DataTable): DataTable {
  if (kind === "heat") return generatePowerLaw({ n: 400, seed: 1, noise: 0.05 });
  if (kind === "additive") return generateAdditive({ n: 300, seed: 11 });
  if (kind === "noise") return generateNoise({ n: 400, seed: 7 });
  if (kind === "tiny") return generateTiny();
  if (!csv) return generatePowerLaw({ n: 400, seed: 1 });
  return csv;
}

export function Workbench() {
  const [kind, setKind] = useState<DatasetKind>("heat");
  const [csvTable, setCsvTable] = useState<DataTable | null>(null);
  const [csvError, setCsvError] = useState<string | null>(null);
  const [thorough, setThorough] = useState(false);
  const [engineBackend, setEngineBackend] = useState<EngineBackend>("gp");
  const [juliaReady, setJuliaReady] = useState(false);
  const [engineNote, setEngineNote] = useState("Probing Julia/PySR…");
  const [methodOpen, setMethodOpen] = useState(false);
  const [tab, setTab] = useState<"equation" | "stability" | "validation" | "card">("equation");

  const table = useMemo(() => loadDataset(kind, csvTable ?? undefined), [kind, csvTable]);
  const features = table.columns.filter((c) => c !== table.target);

  const [target, setTarget] = useState(table.target);
  useEffect(() => {
    setTarget(table.target);
  }, [table.id, table.target]);

  const cfg: PipelineConfig = useMemo(() => {
    const c = defaultConfig({
      target,
      features: table.columns.filter((col) => col !== target),
      thorough,
    });
    c.engine.backend = engineBackend;
    if (engineBackend === "pysr" || (engineBackend === "auto" && juliaReady)) {
      c.engine.niterations = thorough ? 28 : 14;
      c.engine.populations = thorough ? 8 : 5;
      c.engine.populationSize = thorough ? 33 : 22;
    }
    return c;
  }, [target, table, thorough, engineBackend, juliaReady]);

  useEffect(() => {
    let cancelled = false;
    probePysr()
      .then((r) => {
        if (cancelled) return;
        const ready = Boolean(r.ok && r.julia && r.pysr);
        setJuliaProbe({ julia: ready, pysr: ready, reason: r.reason ?? r.error ?? "" });
        setJuliaReady(ready);
        setEngineNote(r.reason ?? r.error ?? (ready ? "PySR ready." : "PySR not ready."));
      })
      .catch((err) => {
        if (cancelled) return;
        setJuliaReady(false);
        setEngineNote(err instanceof Error ? err.message : String(err));
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const preview = useMemo(() => {
    try {
      return previewScreenAndTransforms(table, cfg);
    } catch {
      return null;
    }
  }, [table, cfg]);

  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<Progress | null>(null);
  const [result, setResult] = useState<PipelineResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const runGen = useRef(0);
  const [draft, setDraft] = useState("");
  const [userScore, setUserScore] = useState<UserScore | null>(null);

  useEffect(() => {
    setResult(null);
    setError(null);
    setProgress(null);
    setTab("equation");
    setUserScore(null);
  }, [table.id, target, thorough, engineBackend]);

  async function onRun() {
    const gen = ++runGen.current;
    setRunning(true);
    setError(null);
    setProgress({ phase: "screen", message: "Starting…", ratio: 0.02 });
    try {
      const res = await runPipeline(table, cfg, (p) => {
        if (runGen.current === gen) setProgress(p);
      });
      if (runGen.current !== gen) return;
      setResult(res);
      setTab(res.stability?.refuseEquation ? "stability" : "equation");
    } catch (err) {
      if (runGen.current !== gen) return;
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      if (runGen.current === gen) setRunning(false);
    }
  }

  function onCsv(file: File) {
    setCsvError(null);
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const t = tableFromCsv(String(reader.result), file.name);
        setCsvTable(t);
        setKind("csv");
      } catch (err) {
        setCsvError(err instanceof Error ? err.message : String(err));
      }
    };
    reader.readAsText(file);
  }

  function onEvaluate() {
    const s = scoreUserExpression(draft, table, target);
    setUserScore(s);
  }

  const example = exampleFor(table.columns, target);
  const screening = preview?.screening ?? null;
  const transforms = preview?.transforms ?? [];
  const targetTf = preview?.targetTransform;

  return (
    <div className="min-h-svh overflow-x-hidden bg-bg">
      <Header onMethod={() => setMethodOpen(true)} />
      <div className="mx-auto grid min-w-0 max-w-6xl gap-6 px-4 pb-16 pt-6 lg:grid-cols-[17.5rem_1fr] lg:gap-8 lg:px-6">
        <aside className="flex min-w-0 flex-col gap-5">
          <section>
            <p className="mb-2 text-xs font-medium uppercase tracking-[0.16em] text-muted">Dataset</p>
            <div className="flex w-full min-w-0 gap-2 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible">
              {DATASETS.map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => {
                    if (d.id === "csv") document.getElementById("csv-input")?.click();
                    else setKind(d.id);
                  }}
                  className={cn(
                    "min-w-[11rem] rounded-lg bg-surface p-3 text-left shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] lg:min-w-0",
                    kind === d.id && "ring-1 ring-accent/40",
                  )}
                >
                  <div className="text-sm font-medium">{d.title}</div>
                  <div className="mt-1 text-xs leading-snug text-muted">{d.blurb}</div>
                </button>
              ))}
            </div>
            <input
              id="csv-input"
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onCsv(f);
                e.target.value = "";
              }}
            />
            {csvError && <p className="mt-2 text-xs text-fail">{csvError}</p>}
            <p className="mt-2 text-xs leading-relaxed text-muted">
              Header row, comma-separated numbers, last column is the target. Need ≥200 rows and ≤15
              features.{" "}
              <a
                href="/sample-heat.csv"
                download="sample-heat.csv"
                className="text-accent underline-offset-2 hover:underline"
              >
                Download a 400-row sample
              </a>
              .
            </p>
          </section>

          <section className="rounded-lg bg-surface p-4 shadow-[var(--shadow-border)]">
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Target</p>
            <label className="mt-2 block">
              <span className="sr-only">Target column</span>
              <div className="relative">
                <select
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                  className="h-11 w-full appearance-none rounded-md bg-bg px-3 pr-9 text-sm shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
                >
                  {table.columns.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
              </div>
            </label>
            <p className="mt-3 break-words font-mono text-[11px] leading-relaxed text-muted">
              {table.rows.length} rows · {features.length} features
              {table.knownEquation ? ` · ${table.knownEquation}` : ""}
            </p>
            <p className="mt-1 text-xs text-subtle">{table.provenance}</p>
          </section>

          <ExpressionPanel
            draft={draft}
            setDraft={setDraft}
            example={example}
            score={userScore}
            onEvaluate={onEvaluate}
            target={target}
          />

          <section className="rounded-lg bg-surface p-4 shadow-[var(--shadow-border)]">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Search</p>
                <p className="mt-1 text-sm text-muted">
                  {thorough ? "Thorough (7 seeds, 5-fold CV)" : "Quick (5 seeds, 3-fold CV)"}
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={thorough}
                onClick={() => setThorough((v) => !v)}
                className={cn(
                  "relative h-7 w-11 rounded-full transition-colors duration-150",
                  thorough ? "bg-accent" : "bg-fg/15",
                )}
              >
                <span
                  className={cn(
                    "absolute top-0.5 left-0.5 size-6 rounded-full bg-surface transition-transform duration-150",
                    thorough && "translate-x-4",
                  )}
                />
              </button>
            </div>
            <p className="mt-3 font-mono text-[11px] text-subtle">
              {describeEngine(engineBackend).used.toUpperCase()} · {cfg.engine.niterations} iters ·{" "}
              {cfg.engine.populations} pops · {cfg.stability.nSeeds} seeds
            </p>
            <div className="mt-3 flex gap-1">
              {(["auto", "pysr", "gp"] as EngineBackend[]).map((id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setEngineBackend(id)}
                  className={cn(
                    "h-9 min-w-11 flex-1 rounded-md px-2 text-xs font-medium capitalize transition-colors",
                    engineBackend === id ? "bg-accent text-accent-fg" : "bg-bg text-muted hover:text-fg",
                  )}
                >
                  {id === "pysr" ? "PySR" : id === "gp" ? "GP" : "Auto"}
                </button>
              ))}
            </div>
            {engineBackend === "pysr" && !juliaReady && (
              <p className="mt-2 text-xs text-marginal">
                PySR is not ready yet. Discovery will log the downgrade and use GP.
              </p>
            )}
          </section>

          <Button onClick={onRun} disabled={running} className="h-12 w-full rounded-lg">
            {running ? (
              <>
                <Loader2 className="animate-spin" />
                Searching
              </>
            ) : (
              <>
                <Beaker />
                Run discovery
              </>
            )}
          </Button>
        </aside>

        <main className="flex min-w-0 flex-col gap-5">
          <EngineBanner note={engineNote} used={describeEngine(engineBackend).used} julia={juliaReady} />
          {screening && <ScreeningCard screening={screening} transforms={transforms} targetTf={targetTf} />}
          {running && progress && <ProgressCard progress={progress} />}
          {error && (
            <div className="rounded-lg bg-fail/10 px-4 py-3 text-sm text-fail">
              <CircleAlert className="mr-2 inline size-4" />
              {error}
            </div>
          )}
          {userScore && !userScore.error && (
            <CandidateCard score={userScore} result={result} />
          )}
          {result ? (
            <Results result={result} tab={tab} setTab={setTab} userScore={userScore} />
          ) : (
            !running && !userScore && <IdleCard />
          )}
        </main>
      </div>
      <Methodology open={methodOpen} onClose={() => setMethodOpen(false)} />
    </div>
  );
}

function ExpressionPanel({
  draft,
  setDraft,
  example,
  score,
  onEvaluate,
  target,
}: {
  draft: string;
  setDraft: (v: string) => void;
  example: string;
  score: UserScore | null;
  onEvaluate: () => void;
  target: string;
}) {
  return (
    <section className="rounded-lg bg-surface p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Your expression</p>
      <p className="mt-1 text-xs leading-relaxed text-muted">
        Type a candidate in original units. It is scored on this table; it does not become a finding.
      </p>
      <textarea
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
            e.preventDefault();
            onEvaluate();
          }
        }}
        placeholder={`${target} = ${example}`}
        spellCheck={false}
        rows={3}
        className="mt-3 w-full resize-y rounded-md bg-bg px-3 py-2 font-mono text-[13px] leading-relaxed shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
      />
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <Button type="button" size="sm" onClick={onEvaluate} disabled={!draft.trim()}>
          <PencilLine />
          Evaluate
        </Button>
        <button
          type="button"
          onClick={() => setDraft(example)}
          className="truncate font-mono text-[11px] text-accent underline-offset-2 hover:underline"
        >
          {example}
        </button>
      </div>
      {score?.error && <p className="mt-2 text-xs text-fail">{score.error}</p>}
      {score && !score.error && (
        <p className="mt-2 font-mono text-[11px] tabular-nums text-muted">
          R² {score.r2.toFixed(3)} · {score.used.join(", ") || "constant"}
          {score.usesTarget ? " · uses the target" : ""}
        </p>
      )}
    </section>
  );
}

function CandidateCard({ score, result }: { score: UserScore; result: PipelineResult | null }) {
  return (
    <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Candidate (you)</p>
          <div className="mt-2">
            <EquationHero text={score.pretty} />
          </div>
        </div>
        <Badge tone="neutral">Not a finding</Badge>
      </div>
      <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Stat label="Fit R²" value={score.r2.toFixed(3)} />
        <Stat label="MAE" value={fmtNum(score.mae)} />
        <Stat label="Columns" value={score.used.join(", ") || "—"} />
      </dl>
      {score.usesTarget && (
        <p className="mt-3 text-xs text-marginal">This formula uses the target on the right-hand side.</p>
      )}
      {result?.originalEquation && result.validation?.nestedCvR2Mean != null && (
        <p className="mt-3 text-sm text-muted">
          Discovered nested-CV R² is {result.validation.nestedCvR2Mean.toFixed(3)}. Your number is in-sample
          fit, not a held-out score.
        </p>
      )}
    </section>
  );
}

function fmtNum(v: number): string {
  if (!Number.isFinite(v)) return "—";
  const a = Math.abs(v);
  if (a !== 0 && (a >= 1e4 || a < 1e-3)) return v.toExponential(2);
  return v.toPrecision(4);
}

function Header({ onMethod }: { onMethod: () => void }) {
  return (
    <header className="border-b border-border">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 lg:px-6">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-muted">Symbolic transform</p>
          <h1 className="font-display text-2xl tracking-tight sm:text-[1.85rem]">Equation Lab</h1>
        </div>
        <Button variant="ghost" size="sm" onClick={onMethod} className="text-muted">
          <BookOpen />
          Methodology
        </Button>
      </div>
    </header>
  );
}

function EngineBanner({
  note,
  used,
  julia,
}: {
  note: string;
  used: "gp" | "pysr";
  julia: boolean;
}) {
  return (
    <div className={cn("rounded-lg px-4 py-3 text-sm", julia ? "bg-pass/10 text-pass" : "bg-accent/8 text-accent")}>
      {julia
        ? `PySR is available. This run will use ${used === "pysr" ? "PySR (Julia)" : "the GP engine"}.`
        : `PySR/Julia not ready — using the GP fallback. ${note}`}
    </div>
  );
}

function ScreeningCard({
  screening,
  transforms,
  targetTf,
}: {
  screening: ScreeningReport;
  transforms: TransformSpec[];
  targetTf?: TransformSpec;
}) {
  const stops = screening.checks.filter((c) => c.level === "stop");
  const warns = screening.checks.filter((c) => c.level === "warn");
  return (
    <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Screening</p>
          <h2 className="mt-1 font-display text-xl tracking-tight">
            {screening.proceed ? "SR is an appropriate tool" : "Hard stop"}
          </h2>
        </div>
        <Badge tone={screening.proceed ? "pass" : "fail"}>
          {screening.proceed ? "Proceed" : "Rejected"}
        </Badge>
      </div>
      <ul className="mt-4 grid gap-2 sm:grid-cols-2">
        {screening.checks.map((c) => (
          <li key={c.name} className="flex gap-2 text-sm">
            <span className={cn("mt-0.5 font-mono text-[11px]", c.level === "stop" ? "text-fail" : c.level === "warn" ? "text-marginal" : "text-pass")}>
              {c.level === "stop" ? "×" : c.level === "warn" ? "!" : "·"}
            </span>
            <span className="text-muted">{c.message}</span>
          </li>
        ))}
      </ul>
      {screening.noiseCeilingR2 != null && (
        <p className="mt-4 font-mono text-xs text-muted">
          Noise ceiling (boosted trees, 5-fold) R² = {screening.noiseCeilingR2.toFixed(3)}
        </p>
      )}
      {stops.length > 0 && (
        <p className="mt-3 text-sm text-fail">{stops[0]!.message} Discovery will not run.</p>
      )}
      {warns.length > 0 && stops.length === 0 && (
        <p className="mt-3 text-sm text-marginal">{warns.length} warning{warns.length > 1 ? "s" : ""} — search will proceed.</p>
      )}

      <div className="mt-5 overflow-x-auto">
        <p className="mb-2 text-xs font-medium uppercase tracking-[0.16em] text-muted">Transforms</p>
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="text-xs uppercase tracking-wider text-subtle">
              <th className="py-1.5 font-medium">Column</th>
              <th className="py-1.5 font-medium">Kind</th>
              <th className="py-1.5 font-medium">Source</th>
            </tr>
          </thead>
          <tbody className="font-mono text-[13px]">
            {transforms.map((t) => (
              <tr key={t.column} className="border-t border-border">
                <td className="py-1.5">{t.column}</td>
                <td className="py-1.5">{t.kind}</td>
                <td className="py-1.5 text-muted">{t.source}</td>
              </tr>
            ))}
            {targetTf && (
              <tr className="border-t border-border">
                <td className="py-1.5">{targetTf.column} (target)</td>
                <td className="py-1.5">{targetTf.kind}</td>
                <td className="py-1.5 text-muted">{targetTf.source}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function ProgressCard({ progress }: { progress: Progress }) {
  return (
    <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm">{progress.message}</p>
        <span className="font-mono text-xs tabular-nums text-muted">{Math.round(progress.ratio * 100)}%</span>
      </div>
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-fg/10">
        <div
          className="h-full bg-accent transition-[width] duration-200 ease-out"
          style={{ width: `${Math.max(4, progress.ratio * 100)}%` }}
        />
      </div>
      <p className="shimmer mt-3 text-xs text-muted">
        Genetic programming is stochastic. Several seeds run before anything is called a finding.
      </p>
    </section>
  );
}

function IdleCard() {
  return (
    <section className="rounded-xl bg-surface px-5 py-10 text-center shadow-[var(--shadow-border)] sm:px-8">
      <p className="font-display text-2xl tracking-tight">The deliverable is an equation</p>
      <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted">
        Screen the table, log-transform the wide columns, search, then ask several seeds whether
        they agree. If they do not, nothing is reported as a finding.
      </p>
    </section>
  );
}

function Results({
  result,
  tab,
  setTab,
  userScore,
}: {
  result: PipelineResult;
  tab: "equation" | "stability" | "validation" | "card";
  setTab: (t: "equation" | "stability" | "validation" | "card") => void;
  userScore: UserScore | null;
}) {
  const v = result.stability?.verdict;
  const tone = v === "PASS" ? "pass" : v === "FAIL" ? "fail" : v === "MARGINAL" ? "marginal" : "neutral";
  const tabs = [
    { id: "equation" as const, label: "Equation" },
    { id: "stability" as const, label: "Stability" },
    { id: "validation" as const, label: "Validation" },
    { id: "card" as const, label: "Model card" },
  ];

  return (
    <section className="rounded-xl bg-surface shadow-[var(--shadow-border)]">
      <div className="border-b border-border px-5 py-5 sm:px-6">
        <div className="flex flex-wrap items-center gap-2">
          {v && <Badge tone={tone}>{v}</Badge>}
          <Badge tone="accent">{result.engine.used.toUpperCase()}</Badge>
          <span className="font-mono text-[11px] text-subtle">{result.runId}</span>
        </div>
        {result.blockedReason && v === "FAIL" ? (
          <div className="mt-4">
            <h2 className="font-display text-2xl tracking-tight">No usable equation found</h2>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">{result.blockedReason}</p>
          </div>
        ) : result.originalEquation ? (
          <div className="mt-4">
            <EquationHero text={result.originalEquation} />
            {result.validation?.nestedCvR2Mean != null && (
              <p className="mt-3 font-mono text-sm tabular-nums text-muted">
                Nested CV R² {result.validation.nestedCvR2Mean.toFixed(3)} ± {result.validation.nestedCvR2Std?.toFixed(3)}
              </p>
            )}
          </div>
        ) : result.blockedReason ? (
          <div className="mt-4">
            <h2 className="font-display text-2xl tracking-tight">Stopped before search</h2>
            <p className="mt-2 text-sm text-muted">{result.blockedReason}</p>
          </div>
        ) : null}
      </div>

      <div className="flex gap-1 overflow-x-auto px-3 pt-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "h-11 shrink-0 rounded-md px-3 text-sm transition-colors duration-150",
              tab === t.id ? "bg-fg/6 font-medium text-fg" : "text-muted hover:text-fg",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="px-5 py-5 sm:px-6">
        {tab === "equation" && <EquationTab result={result} userScore={userScore} />}
        {tab === "stability" && <StabilityTab result={result} />}
        {tab === "validation" && <ValidationTab result={result} />}
        {tab === "card" && <CardTab result={result} />}
      </div>
    </section>
  );
}

function EquationTab({ result, userScore }: { result: PipelineResult; userScore: UserScore | null }) {
  if (result.stability?.refuseEquation || !result.equation) {
    return (
      <p className="text-sm text-muted">
        No equation is emitted when the stability gate fails. See the feature-frequency table.
      </p>
    );
  }
  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Original units</p>
        <div className="mt-2 text-lg">{result.originalEquation && <MonoEq>{result.originalEquation}</MonoEq>}</div>
      </div>
      {userScore && !userScore.error && (
        <div className="overflow-x-auto rounded-md bg-bg px-3 py-3">
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Yours vs discovered</p>
          <table className="mt-2 w-full text-left text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-wider text-subtle">
                <th className="py-1 font-medium">Source</th>
                <th className="py-1 font-medium">R²</th>
                <th className="py-1 font-medium">Columns</th>
              </tr>
            </thead>
            <tbody className="font-mono text-[13px]">
              <tr className="border-t border-border">
                <td className="py-1.5">You (in-sample)</td>
                <td className="py-1.5 tabular-nums">{userScore.r2.toFixed(3)}</td>
                <td className="py-1.5 text-muted">{userScore.used.join(", ")}</td>
              </tr>
              <tr className="border-t border-border">
                <td className="py-1.5">GP nested CV</td>
                <td className="py-1.5 tabular-nums">
                  {result.validation?.nestedCvR2Mean != null
                    ? result.validation.nestedCvR2Mean.toFixed(3)
                    : "—"}
                </td>
                <td className="py-1.5 text-muted">{result.equation.featureNames.join(", ")}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Transformed space</p>
        <p className="mt-2">
          <MonoEq>{result.equation.rawString}</MonoEq>
        </p>
      </div>
      {result.originalLatex && (
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">LaTeX</p>
          <pre className="mt-2 overflow-x-auto font-mono text-xs text-muted">{result.originalLatex}</pre>
        </div>
      )}
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Pareto front</p>
        <p className="mt-1 text-xs text-subtle">Selected complexity marked in teal. Loss on a log₁₀ scale.</p>
        <ParetoChart points={result.pareto} selected={result.equation.complexity} />
      </div>
    </div>
  );
}

function StabilityTab({ result }: { result: PipelineResult }) {
  const s = result.stability;
  if (!s) return <p className="text-sm text-muted">Screening stopped the run before stability.</p>;
  const freq = Object.entries(s.featureFrequency).sort((a, b) => b[1] - a[1]);
  const max = Math.max(...freq.map(([, p]) => p), 0.01);
  return (
    <div className="space-y-6">
      <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Feature agreement" value={pct(s.featureAgreement)} />
        <Stat label="Structure agreement" value={pct(s.structureAgreement)} />
        <Stat label="Coef. CV" value={s.coefCv.toPrecision(3)} />
        <Stat label="Complexity IQR" value={String(s.complexityIqr)} />
      </dl>
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Feature frequency</p>
        <ul className="mt-3 space-y-2">
          {freq.map(([f, p]) => (
            <li key={f} className="grid grid-cols-[7rem_1fr_3rem] items-center gap-2 text-sm">
              <span className="truncate font-mono text-xs">{f}</span>
              <div className="h-2 rounded-full bg-fg/8">
                <div className="h-full rounded-full bg-accent" style={{ width: `${(p / max) * 100}%` }} />
              </div>
              <span className="text-right font-mono text-xs tabular-nums text-muted">{pct(p)}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[24rem] text-left text-sm">
          <thead>
            <tr className="text-xs uppercase tracking-wider text-subtle">
              <th className="py-1.5 font-medium">Seed</th>
              <th className="py-1.5 font-medium">Features</th>
              <th className="py-1.5 font-medium">C</th>
              <th className="py-1.5 font-medium">Equation</th>
            </tr>
          </thead>
          <tbody>
            {s.perSeed.map((row) => (
              <tr key={row.seed} className="border-t border-border align-top">
                <td className="py-2 font-mono text-xs">{row.seed}</td>
                <td className="py-2 font-mono text-xs">{row.features.join(", ") || "—"}</td>
                <td className="py-2 font-mono text-xs">{row.complexity}</td>
                <td className="py-2 font-mono text-[11px] leading-relaxed text-muted">{row.rawString}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ValidationTab({ result }: { result: PipelineResult }) {
  const v = result.validation;
  if (!v) return <p className="text-sm text-muted">No validation (run was blocked).</p>;
  const ceiling = v.baselines.find((b) => b.name.startsWith("Boosted"));
  return (
    <div className="space-y-6">
      {v.nestedCvR2Mean != null ? (
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Headline</p>
          <p className="mt-1 font-display text-3xl tracking-tight tabular-nums">
            {v.nestedCvR2Mean.toFixed(3)}
            <span className="text-xl text-muted"> ± {v.nestedCvR2Std?.toFixed(3)}</span>
          </p>
          <p className="mt-1 text-xs text-subtle">Nested CV R², original units. Not the split used to pick the equation.</p>
        </div>
      ) : (
        <p className="text-sm text-muted">Nested CV skipped because the stability gate failed.</p>
      )}
      {v.beatsTransformedLinear === false && (
        <p className="rounded-md bg-marginal/10 px-3 py-2 text-sm text-marginal">
          SR does not beat transformed-linear by a meaningful margin. The transform is doing the work.
        </p>
      )}
      {v.leakageWarning && (
        <p className="rounded-md bg-fail/10 px-3 py-2 text-sm text-fail">
          SR nested-CV R² sits above the boosted-tree noise ceiling. Treat this as leakage, not a win.
        </p>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="text-xs uppercase tracking-wider text-subtle">
              <th className="py-1.5 font-medium">Model</th>
              <th className="py-1.5 font-medium">R² mean</th>
              <th className="py-1.5 font-medium">R² std</th>
            </tr>
          </thead>
          <tbody className="font-mono text-[13px]">
            {v.baselines.map((b) => (
              <tr key={b.name} className="border-t border-border">
                <td className="py-1.5">{b.name}</td>
                <td className="py-1.5 tabular-nums">{b.r2Mean.toFixed(3)}</td>
                <td className="py-1.5 tabular-nums text-muted">{b.r2Std.toFixed(3)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {ceiling && v.nestedCvR2Mean != null && (
        <p className="text-xs text-subtle">
          Distance to noise ceiling: {(v.nestedCvR2Mean - ceiling.r2Mean).toFixed(3)}
        </p>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Residuals vs fitted</p>
          <ResidualChart points={v.residualFitted} xKey="fitted" xLabel="fitted" />
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Q–Q</p>
          <ResidualChart
            points={v.qq.map((q) => ({ x: q.theoretical, residual: q.sample }))}
            xKey="x"
            xLabel="theoretical"
          />
        </div>
      </div>
    </div>
  );
}

function CardTab({ result }: { result: PipelineResult }) {
  function download(filename: string, body: string) {
    const blob = new Blob([body], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        <Button variant="secondary" size="sm" onClick={() => download(`${result.runId}-model-card.md`, result.modelCard)}>
          <Download /> Model card
        </Button>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => download(`${result.runId}-config.yaml`, configToYaml(result.config))}
        >
          <Download /> Config
        </Button>
        {result.equationText && (
          <Button variant="secondary" size="sm" onClick={() => download(`${result.runId}-equation.txt`, result.equationText)}>
            <Download /> Equation
          </Button>
        )}
      </div>
      <pre className="mt-4 max-h-[32rem] overflow-auto whitespace-pre-wrap font-mono text-[12px] leading-relaxed text-fg">
        {result.modelCard}
      </pre>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-bg p-3">
      <dt className="text-[11px] uppercase tracking-wider text-subtle">{label}</dt>
      <dd className="mt-1 font-mono text-sm tabular-nums">{value}</dd>
    </div>
  );
}

function pct(x: number): string {
  return `${Math.round(x * 100)}%`;
}

