import type { ReactNode } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Methodology({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-40 flex items-end justify-center bg-fg/30 p-3 sm:items-center"
      onClick={onClose}
      role="presentation"
    >
      <div
        role="dialog"
        aria-labelledby="method-title"
        className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Pipeline</p>
            <h2 id="method-title" className="mt-1 font-display text-2xl tracking-tight">
              How a finding is earned
            </h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close">
            <X />
          </Button>
        </div>
        <div className="mt-6 space-y-5 text-sm leading-relaxed text-fg">
          <p className="text-muted">
            Given a table with a continuous target, search for a short algebraic expression
            that predicts it. Unlike a GBM, the deliverable is the equation — and only if it
            survives the gates below. You can type your own candidate; it is scored in-sample
            and never replaces a gated finding.
          </p>
          <Step n="1" title="Screen">
            Refuse to run when SR is the wrong tool: fewer than 200 rows, more than 15 features,
            a non-continuous target, categoricals, or a dead target. A boosted-tree CV R² is
            stored as the noise ceiling; an SR R² above it is leakage, not a win.
          </Step>
          <Step n="2" title="Invertible transforms">
            Power laws are linear in log space. Each column is mapped with{" "}
            <code className="font-mono text-xs">identity</code>,{" "}
            <code className="font-mono text-xs">log</code>,{" "}
            <code className="font-mono text-xs">log1p</code>, or{" "}
            <code className="font-mono text-xs">signed_log</code>. Every transform is invertible
            and recorded, so the back-transform is exact.
          </Step>
          <Step n="3" title="Engine">
            Auto selects PySR when Julia is reachable, otherwise a pure-JS multi-population GP
            (tournament selection, subtree crossover, five mutations, migration, Nelder–Mead
            constants). You can force PySR or GP. Engine choice is logged, never silent.
          </Step>
          <Step n="4" title="Stability gate">
            Fit on the same split with several seeds. PASS requires feature agreement ≥ 70% and
            coefficient CV {"<"} 0.15. On FAIL the pipeline refuses to emit an equation and
            returns a feature-frequency table instead. There is no bypass flag.
          </Step>
          <Step n="5" title="Nested CV">
            Reported R² is the mean ± std of outer-fold test scores. The equation is selected
            inside each fold; the headline number is never the split used to pick it off the
            Pareto front. A baseline gauntlet (raw linear, transformed linear, degree-2 ridge,
            boosted trees) runs on the same folds.
          </Step>
          <Step n="6" title="Back-transform">
            If the target was logged,{" "}
            <span className="font-display italic">ln z = c + a ln x + b ln y</span> is reported
            as <span className="font-display italic">z = eᶜ · xᵃ · yᵇ</span>. Coefficients round
            to four significant figures for display.
          </Step>
        </div>
      </div>
    </div>
  );
}

function Step({ n, title, children }: { n: string; title: string; children: ReactNode }) {
  return (
    <div className="grid grid-cols-[2rem_1fr] gap-3">
      <div className="font-mono text-xs text-muted pt-1">{n}</div>
      <div>
        <h3 className="font-medium">{title}</h3>
        <p className="mt-1 text-muted">{children}</p>
      </div>
    </div>
  );
}
