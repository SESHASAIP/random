import {
  CartesianGrid,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
  ZAxis,
} from "recharts";

const tick = { fill: "#6a655c", fontSize: 11, fontFamily: "IBM Plex Mono, ui-monospace, monospace" };
const grid = { stroke: "#e2dcd0", strokeDasharray: "3 3" };

export function ParetoChart({
  points,
  selected,
}: {
  points: { complexity: number; loss: number; rawString: string }[];
  selected?: number;
}) {
  if (points.length === 0) return <EmptyPlot label="No Pareto front" />;
  const data = points.map((p) => ({
    ...p,
    logLoss: Math.log10(Math.max(p.loss, 1e-16)),
    selected: p.complexity === selected,
  }));
  return (
    <div className="h-56 w-full">
      <ResponsiveContainer>
        <ScatterChart margin={{ top: 8, right: 8, bottom: 4, left: 0 }}>
          <CartesianGrid {...grid} />
          <XAxis dataKey="complexity" type="number" name="complexity" tick={tick} tickLine={false} axisLine={false} />
          <YAxis
            dataKey="logLoss"
            type="number"
            name="log10 loss"
            tick={tick}
            tickLine={false}
            axisLine={false}
            width={42}
          />
          <ZAxis range={[40, 40]} />
          <Tooltip
            cursor={{ stroke: "#1a4d48", strokeDasharray: "4 4" }}
            content={({ payload }) => {
              const p = payload?.[0]?.payload as (typeof data)[0] | undefined;
              if (!p) return null;
              return (
                <div className="rounded-md bg-surface px-3 py-2 shadow-[var(--shadow-border)]">
                  <div className="font-mono text-xs text-muted">complexity {p.complexity}</div>
                  <div className="font-mono text-xs">loss {p.loss.toExponential(3)}</div>
                  <div className="mt-1 max-w-56 font-mono text-[11px] text-fg">{p.rawString}</div>
                </div>
              );
            }}
          />
          <Scatter data={data.filter((d) => !d.selected)} fill="#8a8478" />
          <Scatter data={data.filter((d) => d.selected)} fill="#1a4d48" />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ResidualChart({
  points,
  xKey,
  xLabel,
}: {
  points: { x?: number; fitted?: number; residual: number }[];
  xKey: "x" | "fitted";
  xLabel: string;
}) {
  if (points.length === 0) return <EmptyPlot label="No residuals" />;
  const data = points.map((p) => ({ x: xKey === "fitted" ? p.fitted : p.x, residual: p.residual }));
  return (
    <div className="h-52 w-full">
      <ResponsiveContainer>
        <ScatterChart margin={{ top: 8, right: 8, bottom: 4, left: 0 }}>
          <CartesianGrid {...grid} />
          <XAxis dataKey="x" type="number" name={xLabel} tick={tick} tickLine={false} axisLine={false} />
          <YAxis dataKey="residual" type="number" name="residual" tick={tick} tickLine={false} axisLine={false} width={42} />
          <ZAxis range={[16, 16]} />
          <Tooltip
            content={({ payload }) => {
              const p = payload?.[0]?.payload as { x: number; residual: number } | undefined;
              if (!p) return null;
              return (
                <div className="rounded-md bg-surface px-3 py-2 font-mono text-xs shadow-[var(--shadow-border)]">
                  {xLabel} {fmt(p.x)}
                  <br />
                  residual {fmt(p.residual)}
                </div>
              );
            }}
          />
          <Scatter data={data} fill="#1a4d48" fillOpacity={0.55} />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}

function fmt(n: number): string {
  if (!Number.isFinite(n)) return "—";
  const a = Math.abs(n);
  if (a !== 0 && (a >= 1e4 || a < 1e-3)) return n.toExponential(2);
  return n.toPrecision(4);
}

function EmptyPlot({ label }: { label: string }) {
  return (
    <div className="flex h-40 items-center justify-center text-sm text-muted">{label}</div>
  );
}
