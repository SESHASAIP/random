import { r2Score, variance } from "./linalg.ts";
import { columnValues, uniqueRowFraction } from "./data.ts";
import { fitBoostedTrees, predictBoostedTrees } from "./trees.ts";
import { kfold } from "./data.ts";
import type { DataTable, ScreeningCheck, ScreeningReport } from "./types.ts";

function isContinuous(values: number[]): boolean {
  const finite = values.filter(Number.isFinite);
  if (finite.length < 2) return false;
  const uniq = new Set(finite.map((v) => v.toPrecision(10)));
  if (uniq.size <= 8 && uniq.size / finite.length < 0.05) return false;
  return true;
}

function looksCategorical(values: number[]): boolean {
  const finite = values.filter(Number.isFinite);
  const uniq = new Set(finite.map((v) => v.toPrecision(8)));
  return uniq.size <= 12 && uniq.size / Math.max(finite.length, 1) < 0.08;
}

export function screen(
  table: DataTable,
  features: string[],
  target: string,
): ScreeningReport {
  const checks: ScreeningCheck[] = [];
  const nRows = table.rows.length;
  const nFeatures = features.length;
  const y = columnValues(table, target);

  if (nRows < 200) {
    checks.push({
      name: "n_rows",
      ok: false,
      level: "stop",
      message: `n_rows = ${nRows} is below 200. Overfit risk dominates; collect more data.`,
    });
  } else {
    checks.push({
      name: "n_rows",
      ok: true,
      level: "pass",
      message: `n_rows = ${nRows} (≥ 200).`,
    });
  }

  if (nFeatures > 15) {
    checks.push({
      name: "n_features",
      ok: false,
      level: "stop",
      message: `n_features = ${nFeatures} exceeds 15. Run feature selection first.`,
    });
  } else if (nFeatures >= 10) {
    checks.push({
      name: "n_features",
      ok: true,
      level: "warn",
      message: `n_features = ${nFeatures} is in the 10–15 band. Recommend select_k_features before search.`,
    });
  } else {
    checks.push({
      name: "n_features",
      ok: true,
      level: "pass",
      message: `n_features = ${nFeatures} (≤ 9, comfortable for SR).`,
    });
  }

  if (!isContinuous(y)) {
    checks.push({
      name: "target_dtype",
      ok: false,
      level: "stop",
      message: `Target "${target}" does not look continuous.`,
    });
  } else {
    checks.push({
      name: "target_dtype",
      ok: true,
      level: "pass",
      message: `Target "${target}" is continuous.`,
    });
  }

  const cat = features.filter((f) => looksCategorical(columnValues(table, f)));
  if (cat.length > 0) {
    checks.push({
      name: "categorical_cols",
      ok: false,
      level: "stop",
      message: `Categorical columns present (${cat.join(", ")}). Drop them or stratify explicitly.`,
    });
  } else {
    checks.push({
      name: "categorical_cols",
      ok: true,
      level: "pass",
      message: "No categorical columns detected.",
    });
  }

  const ratio = nFeatures > 0 ? nRows / nFeatures : 0;
  if (ratio < 20) {
    checks.push({
      name: "rows_per_feature",
      ok: true,
      level: "warn",
      message: `rows/features = ${ratio.toFixed(1)} is below 20. Expect fragile equations.`,
    });
  } else {
    checks.push({
      name: "rows_per_feature",
      ok: true,
      level: "pass",
      message: `rows/features = ${ratio.toFixed(1)} (≥ 20).`,
    });
  }

  const yVar = variance(y.filter(Number.isFinite));
  if (yVar < 1e-18) {
    checks.push({
      name: "target_variance",
      ok: false,
      level: "stop",
      message: "Target variance is ~0. Nothing to predict.",
    });
  } else {
    checks.push({
      name: "target_variance",
      ok: true,
      level: "pass",
      message: `Target variance = ${yVar.toPrecision(3)}.`,
    });
  }

  const uniq = uniqueRowFraction(table);
  const dup = 1 - uniq;
  if (dup > 0.05) {
    checks.push({
      name: "duplicate_rows",
      ok: true,
      level: "warn",
      message: `${(dup * 100).toFixed(1)}% duplicate rows — inflates apparent fit.`,
    });
  } else {
    checks.push({
      name: "duplicate_rows",
      ok: true,
      level: "pass",
      message: `${(dup * 100).toFixed(1)}% duplicate rows.`,
    });
  }

  const proceed = checks.every((c) => c.level !== "stop");

  let noiseCeilingR2: number | null = null;
  let noiseCeilingNote = "Skipped — screening did not proceed.";
  if (proceed) {
    try {
      noiseCeilingR2 = estimateNoiseCeiling(table, features, target);
      noiseCeilingNote =
        "Boosted-tree 5-fold CV R² on raw features. Practical upper bound; SR above this is a leakage signal.";
    } catch (err) {
      noiseCeilingNote = `Noise ceiling failed: ${err instanceof Error ? err.message : String(err)}`;
    }
  }

  return {
    proceed,
    nRows,
    nFeatures,
    target,
    features,
    checks,
    noiseCeilingR2,
    noiseCeilingNote,
  };
}

export function estimateNoiseCeiling(table: DataTable, features: string[], target: string): number {
  const n = table.rows.length;
  const X = table.rows.map((r) => features.map((f) => r[table.columns.indexOf(f)]!));
  const y = columnValues(table, target);
  const folds = kfold(n, 5, 1);
  const scores: number[] = [];
  for (let k = 0; k < folds.length; k++) {
    const test = folds[k]!;
    const train: number[] = [];
    for (let j = 0; j < folds.length; j++) if (j !== k) train.push(...folds[j]!);
    const Xtr = train.map((i) => X[i]!);
    const ytr = train.map((i) => y[i]!);
    const Xte = test.map((i) => X[i]!);
    const yte = test.map((i) => y[i]!);
    const model = fitBoostedTrees(Xtr, ytr, { nTrees: 40, maxDepth: 3, learningRate: 0.1, nBins: 8 });
    const pred = predictBoostedTrees(model, Xte);
    scores.push(r2Score(pred, yte));
  }
  return scores.reduce((a, b) => a + b, 0) / scores.length;
}
