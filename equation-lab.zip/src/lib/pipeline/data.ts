import { mulberry32, randn } from "./rng.ts";
import type { DataTable } from "./types.ts";

function col(rows: number[][], j: number): number[] {
  return rows.map((r) => r[j]!);
}

export function columnValues(table: DataTable, name: string): number[] {
  const j = table.columns.indexOf(name);
  if (j < 0) throw new Error(`Unknown column ${name}`);
  return col(table.rows, j);
}

export function dropDuplicateRows(table: DataTable): DataTable {
  const seen = new Set<string>();
  const rows: number[][] = [];
  for (const row of table.rows) {
    const key = row.map((v) => v.toPrecision(12)).join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push(row);
  }
  return { ...table, rows };
}

export function uniqueRowFraction(table: DataTable): number {
  const seen = new Set<string>();
  for (const row of table.rows) seen.add(row.map((v) => v.toPrecision(12)).join("|"));
  return seen.size / Math.max(table.rows.length, 1);
}

export function parseCsv(text: string): { headers: string[]; rows: number[][] } {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) throw new Error("CSV needs a header row and at least one data row.");
  const headers = splitCsvLine(lines[0]!).map((h) => h.trim());
  if (headers.some((h) => !h) || new Set(headers).size !== headers.length) {
    throw new Error("CSV headers must be unique, non-empty names.");
  }
  const rows: number[][] = [];
  for (let i = 1; i < lines.length; i++) {
    const parts = splitCsvLine(lines[i]!);
    if (parts.length !== headers.length) {
      throw new Error(`Row ${i + 1} has ${parts.length} fields, expected ${headers.length}.`);
    }
    rows.push(parts.map((p) => {
      const v = Number(p.trim());
      return Number.isFinite(v) ? v : NaN;
    }));
  }
  return { headers, rows };
}

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i]!;
    if (inQ) {
      if (ch === '"' && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else if (ch === '"') {
        inQ = false;
      } else {
        cur += ch;
      }
    } else if (ch === '"') {
      inQ = true;
    } else if (ch === ",") {
      out.push(cur);
      cur = "";
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out;
}

export function tableFromCsv(text: string, name = "uploaded.csv"): DataTable {
  const { headers, rows } = parseCsv(text);
  const numeric = headers.filter((_, j) => rows.every((r) => Number.isFinite(r[j]!)));
  if (numeric.length < 2) throw new Error("Need at least two numeric columns (features + target).");
  const idx = numeric.map((h) => headers.indexOf(h));
  const trimmed = rows.map((r) => idx.map((j) => r[j]!));
  return {
    id: "csv",
    name,
    provenance: `Uploaded CSV · ${trimmed.length} rows · ${numeric.length} numeric columns`,
    columns: numeric,
    rows: trimmed,
    target: numeric[numeric.length - 1]!,
  };
}

function logUniform(rng: () => number, lo: number, hi: number): number {
  const a = Math.log(lo);
  const b = Math.log(hi);
  return Math.exp(a + rng() * (b - a));
}

function uniform(rng: () => number, lo: number, hi: number): number {
  return lo + rng() * (hi - lo);
}

/**
 * Nu = 0.023 · Re^0.8 · Pr^0.4 with four decoy columns and multiplicative noise.
 * Re/Pr span > 1.5 orders of magnitude so auto-transforms select log.
 */
export function generatePowerLaw(opts?: {
  n?: number;
  seed?: number;
  noise?: number;
  id?: string;
  name?: string;
}): DataTable {
  const n = opts?.n ?? 400;
  const seed = opts?.seed ?? 1;
  const noise = opts?.noise ?? 0.05;
  const rng = mulberry32(seed);
  const columns = ["Re", "Pr", "rough", "T_amb", "wall", "L_over_D", "Nu"];
  const rows: number[][] = [];
  for (let i = 0; i < n; i++) {
    const Re = logUniform(rng, 8e2, 1.2e5);
    const Pr = logUniform(rng, 0.2, 16);
    const rough = uniform(rng, 0.01, 0.08);
    const T_amb = uniform(rng, 285, 310);
    const wall = uniform(rng, 300, 360);
    const L_over_D = uniform(rng, 10, 25);
    const trueNu = 0.023 * Re ** 0.8 * Pr ** 0.4;
    const Nu = trueNu * (1 + noise * randn(rng));
    rows.push([Re, Pr, rough, T_amb, wall, L_over_D, Math.max(Nu, 1e-8)]);
  }
  return {
    id: opts?.id ?? "heat",
    name: opts?.name ?? "Dittus–Boelter heat transfer",
    provenance: `Synthetic · n=${n} · Nu = 0.023·Re^0.8·Pr^0.4 · ${Math.round(noise * 100)}% multiplicative noise · seed ${seed}`,
    columns,
    rows,
    target: "Nu",
    knownEquation: "Nu = 0.023 · Re^{0.8} · Pr^{0.4}",
  };
}

/** Same features as the heat-transfer table; target is pure Gaussian noise. */
export function generateNoise(opts?: { n?: number; seed?: number }): DataTable {
  const base = generatePowerLaw({ n: opts?.n ?? 400, seed: opts?.seed ?? 7, noise: 0 });
  const rng = mulberry32((opts?.seed ?? 7) + 99);
  const ti = base.columns.indexOf("Nu");
  for (const row of base.rows) row[ti] = randn(rng);
  return {
    ...base,
    id: "noise",
    name: "Pure-noise target",
    provenance: `Synthetic · n=${base.rows.length} · target ~ N(0,1), independent of features · seed ${opts?.seed ?? 7}`,
    target: "Nu",
    knownEquation: undefined,
  };
}

export function generateTiny(): DataTable {
  return generatePowerLaw({ n: 50, seed: 3, noise: 0.05, id: "tiny", name: "Undersized sample (50 rows)" });
}

/** y = 2.5·x0 + x1·x2, 300 clean rows. Engine acceptance fixture. */
export function generateAdditive(opts?: { n?: number; seed?: number }): DataTable {
  const n = opts?.n ?? 300;
  const seed = opts?.seed ?? 11;
  const rng = mulberry32(seed);
  const columns = ["x0", "x1", "x2", "y"];
  const rows: number[][] = [];
  for (let i = 0; i < n; i++) {
    const x0 = uniform(rng, -2, 2);
    const x1 = uniform(rng, -2, 2);
    const x2 = uniform(rng, -2, 2);
    const y = 2.5 * x0 + x1 * x2;
    rows.push([x0, x1, x2, y]);
  }
  return {
    id: "additive",
    name: "Additive-multiplicative identity",
    provenance: `Synthetic · n=${n} · y = 2.5·x0 + x1·x2 · noiseless · seed ${seed}`,
    columns,
    rows,
    target: "y",
    knownEquation: "y = 2.5·x0 + x1·x2",
  };
}

export function toColumns(table: DataTable, names: string[]): Float64Array[] {
  return names.map((name) => {
    const j = table.columns.indexOf(name);
    if (j < 0) throw new Error(`Unknown column ${name}`);
    const out = new Float64Array(table.rows.length);
    for (let i = 0; i < table.rows.length; i++) out[i] = table.rows[i]![j]!;
    return out;
  });
}

export function splitIndices(n: number, testSize: number, seed: number): { train: number[]; test: number[] } {
  const rng = mulberry32(seed);
  const idx = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = idx[i]!;
    idx[i] = idx[j]!;
    idx[j] = tmp;
  }
  const nTest = Math.max(1, Math.round(n * testSize));
  return { test: idx.slice(0, nTest), train: idx.slice(nTest) };
}

export function kfold(n: number, k: number, seed: number): number[][] {
  const rng = mulberry32(seed + 17);
  const idx = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = idx[i]!;
    idx[i] = idx[j]!;
    idx[j] = tmp;
  }
  const folds: number[][] = Array.from({ length: k }, () => []);
  idx.forEach((id, i) => folds[i % k]!.push(id));
  return folds;
}

export function takeRows(rows: number[][], idx: number[]): number[][] {
  return idx.map((i) => rows[i]!);
}

export function takeCol(col: Float64Array, idx: number[]): Float64Array {
  const out = new Float64Array(idx.length);
  for (let i = 0; i < idx.length; i++) out[i] = col[idx[i]!]!;
  return out;
}

export function takeCols(cols: Float64Array[], idx: number[]): Float64Array[] {
  return cols.map((c) => takeCol(c, idx));
}
