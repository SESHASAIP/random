export { defaultConfig, configToYaml, pipelineConfigSchema } from "./config.ts";
export {
  generatePowerLaw,
  generateNoise,
  generateTiny,
  generateAdditive,
  tableFromCsv,
  parseCsv,
  columnValues,
} from "./data.ts";
export { screen, estimateNoiseCeiling } from "./screening.ts";
export { recommend, Transform } from "./transforms.ts";
export type { TransformKind } from "./transforms.ts";
export { runPipeline, previewScreenAndTransforms, yieldToMain } from "./pipeline.ts";
export { GPEngine } from "./engines/gp.ts";
export { PySREngine } from "./engines/pysr.ts";
export { getEngine } from "./engines/select.ts";
export { describeEngine, juliaAvailable, setJuliaProbe } from "./engines/base.ts";
export { probePysr } from "./engines/pysr.ts";
export { parseExpression, scoreUserExpression, exampleFor } from "./parse.ts";
export type { UserScore } from "./parse.ts";

export type {
  DataTable,
  PipelineConfig,
  PipelineResult,
  ScreeningReport,
  TransformSpec,
  Progress,
  DatasetKind,
  Equation,
  EngineBackend,
} from "./types.ts";
