import { defaultConfig } from "./config.ts";
import { dropDuplicateRows, kfold, splitIndices, takeCol, takeCols, toColumns } from "./data.ts";
import { describeEngine } from "./engines/base.ts";
import { getEngine } from "./engines/select.ts";
import { applyColumn, recommend, Transform } from "./transforms.ts";
import { screen } from "./screening.ts";
import { runStability } from "./stability.ts";
import { runValidation } from "./validate.ts";
import {
  buildEquationText,
  buildModelCard,
  buildStabilityMarkdown,
  buildValidationMarkdown,
  formatOriginalEquation,
} from "./report.ts";
import type {
  DataTable,
  PipelineConfig,
  PipelineResult,
  Progress,
  TransformSpec,
} from "./types.ts";

export async function yieldToMain(): Promise<void> {
  await new Promise((r) => setTimeout(r, 0));
}

export async function runPipeline(
  tableIn: DataTable,
  cfgIn: PipelineConfig,
  onProgress?: (p: Progress) => void,
  yieldFn: () => Promise<void> = yieldToMain,
): Promise<PipelineResult> {
  const cfg = cfgIn;
  const runId = makeRunId();
  const timestamp = new Date().toISOString();
  const engineInfo = {
    requested: cfg.engine.backend,
    ...describeEngine(cfg.engine.backend),
  };

  const progress = (phase: Progress["phase"], message: string, ratio: number) =>
    onProgress?.({ phase, message, ratio });

  progress("screen", "Running screening gate…", 0.04);
  let table = tableIn;
  if (cfg.data.dropDuplicates) table = dropDuplicateRows(table);

  const features = cfg.data.features.filter((f) => table.columns.includes(f) && f !== cfg.data.target);
  const target = cfg.data.target;
  const screening = screen(table, features, target);

  if (!screening.proceed) {
    const blocked =
      screening.checks.find((c) => c.level === "stop")?.message ?? "Screening rejected this table.";
    const modelCard = buildModelCard({
      runId,
      tableName: table.name,
      provenance: table.provenance,
      nRows: screening.nRows,
      nFeatures: screening.nFeatures,
      cfg,
      engine: engineInfo,
      screening,
      transforms: [],
      targetTransform: { column: target, kind: "identity", source: "auto" },
      stability: null,
      equationText: null,
      validation: null,
      blockedReason: blocked,
    });
    return {
      runId,
      timestamp,
      config: cfg,
      engine: engineInfo,
      screening,
      transforms: [],
      targetTransform: { column: target, kind: "identity", source: "auto" },
      stability: null,
      equation: null,
      originalEquation: null,
      originalLatex: null,
      validation: null,
      pareto: [],
      modelCard,
      stabilityMarkdown: "",
      validationMarkdown: "",
      equationText: "",
      blockedReason: blocked,
    };
  }

  progress("transform", "Recommending invertible transforms…", 0.1);
  await yieldFn();

  const rawFeatCols = toColumns(table, features);
  const rawTarget = toColumns(table, [target])[0]!;

  const transforms: TransformSpec[] = features.map((name, i) => {
    if (!cfg.transforms.auto && cfg.transforms.overrides[name]) {
      return { column: name, kind: cfg.transforms.overrides[name]!, source: "override" };
    }
    if (cfg.transforms.overrides[name]) {
      return { column: name, kind: cfg.transforms.overrides[name]!, source: "override" };
    }
    return { column: name, kind: recommend(rawFeatCols[i]!), source: "auto" };
  });
  const targetTransform: TransformSpec = cfg.transforms.overrides[target]
    ? { column: target, kind: cfg.transforms.overrides[target]!, source: "override" }
    : { column: target, kind: cfg.transforms.auto ? recommend(rawTarget) : "identity", source: cfg.transforms.auto ? "auto" : "override" };

  const tfFeatCols = transforms.map((t, i) => applyColumn(rawFeatCols[i]!, new Transform(t.kind)));
  const tfTarget = applyColumn(rawTarget, new Transform(targetTransform.kind));
  const tfNames = transforms.map((t) => new Transform(t.kind).prefix(t.column));

  const { train, test } = splitIndices(table.rows.length, cfg.validation.testSize, cfg.validation.randomState);
  const Xtr = takeCols(tfFeatCols, train);
  const ytr = takeCol(tfTarget, train);

  progress("stability", `Multi-seed stability · ${cfg.stability.nSeeds} seeds…`, 0.18);
  await yieldFn();

  const seeds = Array.from({ length: cfg.stability.nSeeds }, (_, i) => cfg.validation.randomState + 13 * (i + 1));
  // Run seeds sequentially with yields so the UI can paint.
  const stability = await runStability(
    () => getEngine(cfg),
    Xtr,
    ytr,
    tfNames,
    cfg,
    seeds,
    yieldFn,
    (i, n) => progress("stability", `Stability seed ${i} / ${n}…`, 0.18 + (0.35 * i) / n),
  );
  await yieldFn();

  let equation = null;
  let originalEquation = null;
  let originalLatex = null;
  let equationText = "";
  let pareto: PipelineResult["pareto"] = [];
  let validation = null;

  if (!stability.refuseEquation) {
    progress("fit", "Refitting selected structure on the training split…", 0.55);
    await yieldFn();
    const engine = getEngine(cfg);
    await engine.fit(Xtr, ytr, tfNames, cfg.validation.randomState);
    equation = engine.selectBest();
    pareto = engine.paretoFront().map((e) => ({
      complexity: e.complexity,
      loss: e.loss,
      score: e.score,
      rawString: e.rawString,
    }));
    const formatted = formatOriginalEquation(equation, transforms, targetTransform);
    originalEquation = formatted.text;
    originalLatex = formatted.latex;
    equationText = buildEquationText({
      transformed: formatted.transformed,
      original: formatted.text,
      latex: formatted.latex,
      complexity: equation.complexity,
      loss: equation.loss,
    });

    progress("validate", "Nested CV + baseline gauntlet…", 0.68);
    await yieldFn();
    validation = await runValidation({
      Xtf: tfFeatCols,
      ytf: tfTarget,
      Xraw: rawFeatCols,
      yraw: rawTarget,
      names: tfNames,
      cfg,
      targetKind: targetTransform.kind,
      makeEngine: () => getEngine(cfg),
      holdoutIdx: test,
      trainIdx: train,
      skipNested: false,
    });
  } else {
    progress("validate", "Stability FAIL — skipping equation, running baselines only…", 0.7);
    await yieldFn();
    validation = await runValidation({
      Xtf: tfFeatCols,
      ytf: tfTarget,
      Xraw: rawFeatCols,
      yraw: rawTarget,
      names: tfNames,
      cfg,
      targetKind: targetTransform.kind,
      makeEngine: () => getEngine(cfg),
      holdoutIdx: test,
      trainIdx: train,
      skipNested: true,
    });
  }

  progress("report", "Writing model card…", 0.94);
  await yieldFn();

  const blockedReason = stability.refuseEquation
    ? "The search did not converge on a consistent structure. No equation is emitted. Treat the feature-frequency table as exploratory only."
    : null;

  const modelCard = buildModelCard({
    runId,
    tableName: table.name,
    provenance: table.provenance,
    nRows: screening.nRows,
    nFeatures: screening.nFeatures,
    cfg,
    engine: engineInfo,
    screening,
    transforms,
    targetTransform,
    stability,
    equationText: originalEquation,
    validation,
    blockedReason,
  });

  progress("report", "Done.", 1);

  return {
    runId,
    timestamp,
    config: cfg,
    engine: engineInfo,
    screening,
    transforms,
    targetTransform,
    stability,
    equation,
    originalEquation,
    originalLatex,
    validation,
    pareto,
    modelCard,
    stabilityMarkdown: buildStabilityMarkdown(stability),
    validationMarkdown: validation ? buildValidationMarkdown(validation) : "",
    equationText,
    blockedReason,
  };
}

export function previewScreenAndTransforms(tableIn: DataTable, cfg: PipelineConfig) {
  let table = cfg.data.dropDuplicates ? dropDuplicateRows(tableIn) : tableIn;
  const features = cfg.data.features.filter((f) => table.columns.includes(f) && f !== cfg.data.target);
  const target = cfg.data.target;
  const screening = screen(table, features, target);
  const rawFeatCols = toColumns(table, features);
  const rawTarget = toColumns(table, [target])[0]!;
  const transforms: TransformSpec[] = features.map((name, i) => {
    if (cfg.transforms.overrides[name]) {
      return { column: name, kind: cfg.transforms.overrides[name]!, source: "override" };
    }
    return { column: name, kind: cfg.transforms.auto ? recommend(rawFeatCols[i]!) : "identity", source: "auto" };
  });
  const targetTransform: TransformSpec = cfg.transforms.overrides[target]
    ? { column: target, kind: cfg.transforms.overrides[target]!, source: "override" }
    : { column: target, kind: cfg.transforms.auto ? recommend(rawTarget) : "identity", source: "auto" };
  return { table, screening, transforms, targetTransform };
}

function makeRunId(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

export { defaultConfig };
export { kfold };
