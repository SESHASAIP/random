import { evalAll } from "./expr.ts";
import { mean, quantile, r2Score } from "./linalg.ts";
import { foldR2, predictHgb, predictLinear, predictRidgePoly2, toRowMajor } from "./baselines.ts";
import { kfold, takeCols, takeCol } from "./data.ts";
import type { SREngine } from "./engines/base.ts";
import type { PipelineConfig, TransformSpec, ValidationResult } from "./types.ts";
import { inverseColumn, Transform } from "./transforms.ts";

export async function runValidation(opts: {
  Xtf: Float64Array[];
  ytf: Float64Array;
  Xraw: Float64Array[];
  yraw: Float64Array;
  names: string[];
  cfg: PipelineConfig;
  targetKind: TransformSpec["kind"];
  makeEngine: () => SREngine;
  holdoutIdx: number[];
  trainIdx: number[];
  skipNested: boolean;
}): Promise<ValidationResult> {
  const { cfg, names } = opts;
  const n = opts.yraw.length;
  const folds = kfold(n, cfg.validation.outerFolds, cfg.validation.randomState + 5);

  const XrawM = toRowMajor(opts.Xraw);
  const yraw = Array.from(opts.yraw);
  const XtfM = toRowMajor(opts.Xtf);
  const ytf = Array.from(opts.ytf);

  const linRaw = foldR2(predictLinear, XrawM, yraw, folds);
  const linTf = foldR2(predictLinear, XtfM, ytf, folds);
  // report transformed-linear in original units
  const linTfOrig = foldR2(
    (Xtr, ytr, Xte) => {
      const predTf = predictLinear(Xtr, ytr, Xte);
      const t = new Transform(opts.targetKind);
      return predTf.map((v) => t.inverse(v));
    },
    XtfM,
    ytf,
    folds,
  );
  // The yte in foldR2 is ytf, so r2 is in transformed space. Compute original-space
  // R² with a custom loop:
  const linTfOrigScores = originalSpaceFoldR2(XtfM, ytf, yraw, folds, opts.targetKind, predictLinear);
  const ridge = originalSpaceFoldR2(XrawM, yraw, yraw, folds, "identity", predictRidgePoly2);
  const hgb = originalSpaceFoldR2(XrawM, yraw, yraw, folds, "identity", predictHgb);
  const linRawOrig = originalSpaceFoldR2(XrawM, yraw, yraw, folds, "identity", predictLinear);

  void linTf;
  void linTfOrig;

  let nestedFoldR2: number[] = [];
  let nestedCvR2Mean: number | null = null;
  let nestedCvR2Std: number | null = null;

  if (!opts.skipNested) {
    for (let k = 0; k < folds.length; k++) {
      const test = folds[k]!;
      const train: number[] = [];
      for (let j = 0; j < folds.length; j++) if (j !== k) train.push(...folds[j]!);
      const Xtr = takeCols(opts.Xtf, train);
      const ytr = takeCol(opts.ytf, train);
      const Xte = takeCols(opts.Xtf, test);
      const yteOrig = takeCol(opts.yraw, test);
      let bestPred: Float64Array | null = null;
      let bestLoss = Infinity;
      for (let s = 0; s < cfg.validation.seedsInCv; s++) {
        const inner = opts.makeEngine();
        await inner.fit(Xtr, ytr, names, cfg.validation.randomState + 100 * (k + 1) + s);
        const eq = inner.selectBest();
        if (eq.loss < bestLoss) {
          bestLoss = eq.loss;
          bestPred = evalAll(eq.expr, Xte);
        }
      }
      const t = new Transform(opts.targetKind);
      const predOrig = Array.from(bestPred ?? new Float64Array(test.length)).map((v) => t.inverse(v));
      nestedFoldR2.push(r2Score(predOrig, yteOrig));
    }
    nestedCvR2Mean = mean(nestedFoldR2);
    const v =
      nestedFoldR2.reduce((s, x) => s + (x - nestedCvR2Mean!) ** 2, 0) / nestedFoldR2.length;
    nestedCvR2Std = Math.sqrt(v);
  }

  const XtrH = takeCols(opts.Xtf, opts.trainIdx);
  const ytrH = takeCol(opts.ytf, opts.trainIdx);
  const XteH = takeCols(opts.Xtf, opts.holdoutIdx);
  const yteH = takeCol(opts.yraw, opts.holdoutIdx);
  const engine = opts.makeEngine();
  await engine.fit(XtrH, ytrH, names, cfg.validation.randomState);
  const holdEq = engine.selectBest();
  const t = new Transform(opts.targetKind);
  const holdPredTf = evalAll(holdEq.expr, XteH);
  const holdPred = Array.from(holdPredTf).map((v) => t.inverse(v));
  const holdoutR2 = r2Score(holdPred, yteH);

  const fittedOrig = Array.from(evalAll(holdEq.expr, opts.Xtf)).map((v) => t.inverse(v));
  const residualFitted = fittedOrig.map((f, i) => ({ fitted: f, residual: opts.yraw[i]! - f }));

  const residualByFeature: Record<string, { x: number; residual: number }[]> = {};
  for (let j = 0; j < names.length; j++) {
    const xs = opts.Xraw[j]!;
    residualByFeature[names[j]!.replace(/^ln_|^log1p_|^slog_/, "")] = residualFitted.map((r, i) => ({
      x: xs[i]!,
      residual: r.residual,
    }));
  }

  const res = residualFitted.map((r) => r.residual).slice().sort((a, b) => a - b);
  const qq = res.map((sample, i) => {
    const p = (i + 0.5) / res.length;
    return { theoretical: invNormApprox(p) * std(res), sample };
  });

  const beats =
    nestedCvR2Mean == null ? null : nestedCvR2Mean > linTfOrigScores.mean + 0.01;
  const leakageWarning =
    nestedCvR2Mean != null && hgb.mean > 0 && nestedCvR2Mean > hgb.mean + 0.02;

  return {
    nestedCvR2Mean,
    nestedCvR2Std,
    nestedFoldR2,
    baselines: [
      { name: "Linear (raw features)", r2Mean: linRawOrig.mean, r2Std: linRawOrig.std },
      { name: "Linear (transformed features)", r2Mean: linTfOrigScores.mean, r2Std: linTfOrigScores.std },
      { name: "Ridge · degree-2 polynomial", r2Mean: ridge.mean, r2Std: ridge.std },
      { name: "Boosted trees (noise ceiling)", r2Mean: hgb.mean, r2Std: hgb.std },
    ],
    holdoutR2,
    beatsTransformedLinear: beats,
    leakageWarning,
    residualFitted: downsample(residualFitted, 240),
    residualByFeature: Object.fromEntries(
      Object.entries(residualByFeature).map(([k, v]) => [k, downsample(v, 180)]),
    ),
    qq: downsample(qq, 80),
  };
}

function originalSpaceFoldR2(
  X: number[][],
  yFit: number[],
  yOrig: number[],
  folds: number[][],
  targetKind: TransformSpec["kind"],
  predict: (Xtr: number[][], ytr: number[], Xte: number[][]) => number[],
): { mean: number; std: number; folds: number[] } {
  const t = new Transform(targetKind);
  const scores: number[] = [];
  for (let k = 0; k < folds.length; k++) {
    const test = folds[k]!;
    const train: number[] = [];
    for (let j = 0; j < folds.length; j++) if (j !== k) train.push(...folds[j]!);
    const Xtr = train.map((i) => X[i]!);
    const ytr = train.map((i) => yFit[i]!);
    const Xte = test.map((i) => X[i]!);
    const predFit = predict(Xtr, ytr, Xte);
    const predOrig = predFit.map((v) => t.inverse(v));
    const yte = test.map((i) => yOrig[i]!);
    scores.push(r2Score(predOrig, yte));
  }
  const m = mean(scores);
  const v = scores.reduce((s, x) => s + (x - m) ** 2, 0) / scores.length;
  return { mean: m, std: Math.sqrt(v), folds: scores };
}

function downsample<T>(xs: T[], max: number): T[] {
  if (xs.length <= max) return xs;
  const out: T[] = [];
  for (let i = 0; i < max; i++) out.push(xs[Math.floor((i * (xs.length - 1)) / (max - 1))]!);
  return out;
}

function std(xs: number[]): number {
  const m = mean(xs);
  return Math.sqrt(xs.reduce((s, x) => s + (x - m) ** 2, 0) / xs.length);
}

/** Acklam's inverse-normal approximation. */
function invNormApprox(p: number): number {
  const a = [
    -3.969683028665376e1, 2.209460984351305e2, -2.759285104469687e2, 1.383577509590705e2,
    -3.066479806614716e1, 2.506628277459239e0,
  ];
  const b = [
    -5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1,
    -1.328068155288572e1,
  ];
  const c = [
    -7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838e0, -2.549732539343734e0,
    4.374664141464968e0, 2.938163982698783e0,
  ];
  const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996e0, 3.754408661907416e0];
  const plow = 0.02425;
  const phigh = 1 - plow;
  let q: number;
  let r: number;
  if (p < plow) {
    q = Math.sqrt(-2 * Math.log(p));
    return (
      (((((c[0]! * q + c[1]!) * q + c[2]!) * q + c[3]!) * q + c[4]!) * q + c[5]!) /
      ((((d[0]! * q + d[1]!) * q + d[2]!) * q + d[3]!) * q + 1)
    );
  }
  if (p > phigh) {
    q = Math.sqrt(-2 * Math.log(1 - p));
    return -(
      (((((c[0]! * q + c[1]!) * q + c[2]!) * q + c[3]!) * q + c[4]!) * q + c[5]!) /
      ((((d[0]! * q + d[1]!) * q + d[2]!) * q + d[3]!) * q + 1)
    );
  }
  q = p - 0.5;
  r = q * q;
  return (
    ((((((a[0]! * r + a[1]!) * r + a[2]!) * r + a[3]!) * r + a[4]!) * r + a[5]!) * q) /
    (((((b[0]! * r + b[1]!) * r + b[2]!) * r + b[3]!) * r + b[4]!) * r + 1)
  );
}

export { inverseColumn, quantile };
