import { mse, r2Score } from "./linalg.ts";
import type { DataTable } from "./types.ts";
import type { Expr } from "./expr.ts";

export type UserAst =
  | { t: "c"; v: number }
  | { t: "v"; n: string }
  | { t: "u"; op: UnaryFn; a: UserAst }
  | { t: "b"; op: BinaryFn; l: UserAst; r: UserAst };

export type UnaryFn = "neg" | "exp" | "log" | "log1p" | "square" | "sqrt" | "abs";
export type BinaryFn = "+" | "-" | "*" | "/" | "^";

export type ParseResult =
  | { ok: true; ast: UserAst; lhs: string | null }
  | { ok: false; message: string };

export type UserScore = {
  source: string;
  pretty: string;
  lhs: string | null;
  used: string[];
  r2: number;
  mse: number;
  mae: number;
  n: number;
  nFinite: number;
  usesTarget: boolean;
  error?: string;
};

const FUNS: Record<string, UnaryFn> = {
  exp: "exp",
  log: "log",
  ln: "log",
  log1p: "log1p",
  square: "square",
  sqrt: "sqrt",
  abs: "abs",
};

type Tok =
  | { k: "num"; v: number; i: number }
  | { k: "id"; v: string; i: number }
  | { k: "op"; v: string; i: number }
  | { k: "eof"; i: number };

function tokenize(src: string): Tok[] {
  const s = src.replace(/\u00b7|\u00d7|\u2217/g, "*").replace(/\s+/g, " ").trim();
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const ch = s[i]!;
    if (ch === " ") {
      i++;
      continue;
    }
    if (ch === "*" && s[i + 1] === "*") {
      out.push({ k: "op", v: "^", i });
      i += 2;
      continue;
    }
    if ("+-*/^(),=".includes(ch)) {
      out.push({ k: "op", v: ch, i });
      i++;
      continue;
    }
    if (ch === "." || (ch >= "0" && ch <= "9")) {
      const m = s.slice(i).match(/^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/);
      if (!m) throw new Error(`Bad number at column ${i + 1}.`);
      out.push({ k: "num", v: Number(m[0]), i });
      i += m[0].length;
      continue;
    }
    if (/[A-Za-z_]/.test(ch)) {
      const m = s.slice(i).match(/^[A-Za-z_][A-Za-z0-9_]*/);
      out.push({ k: "id", v: m![0]!, i });
      i += m![0]!.length;
      continue;
    }
    throw new Error(`Unexpected “${ch}” at column ${i + 1}.`);
  }
  out.push({ k: "eof", i: s.length });
  return out;
}

class Parser {
  private p = 0;
  private toks: Tok[];
  constructor(toks: Tok[]) {
    this.toks = toks;
  }

  peek(): Tok {
    return this.toks[this.p]!;
  }
  op(): string | null {
    const t = this.peek();
    return t.k === "op" ? t.v : null;
  }
  eat(v?: string): Tok {
    const t = this.peek();
    if (v && (t.k !== "op" || t.v !== v)) {
      throw new Error(`Expected “${v}”.`);
    }
    this.p++;
    return t;
  }
  eatOp(): string {
    const t = this.peek();
    if (t.k !== "op") throw new Error("Expected an operator.");
    this.p++;
    return t.v;
  }

  parse(): { ast: UserAst; lhs: string | null } {
    let lhs: string | null = null;
    const first = this.peek();
    const next = this.toks[this.p + 1];
    if (first.k === "id" && next?.k === "op" && next.v === "=") {
      lhs = first.v;
      this.eat();
      this.eat("=");
    }
    const ast = this.add();
    if (this.peek().k !== "eof") throw new Error("Unexpected trailing input.");
    return { ast, lhs };
  }

  private add(): UserAst {
    let left = this.mul();
    while (this.op() === "+" || this.op() === "-") {
      const op = this.eatOp() as "+" | "-";
      left = { t: "b", op, l: left, r: this.mul() };
    }
    return left;
  }

  private mul(): UserAst {
    let left = this.pow();
    while (this.op() === "*" || this.op() === "/") {
      const op = this.eatOp() as "*" | "/";
      left = { t: "b", op, l: left, r: this.pow() };
    }
    return left;
  }

  private pow(): UserAst {
    const left = this.unary();
    if (this.op() === "^") {
      this.eat("^");
      return { t: "b", op: "^", l: left, r: this.unary() };
    }
    return left;
  }

  private unary(): UserAst {
    if (this.op() === "-") {
      this.eat("-");
      return { t: "u", op: "neg", a: this.unary() };
    }
    if (this.op() === "+") {
      this.eat("+");
      return this.unary();
    }
    return this.primary();
  }

  private primary(): UserAst {
    const t = this.peek();
    if (t.k === "num") {
      this.eat();
      return { t: "c", v: t.v };
    }
    if (t.k === "id") {
      this.eat();
      const fn = FUNS[t.v.toLowerCase()];
      if (fn) {
        this.eat("(");
        const a = this.add();
        this.eat(")");
        return { t: "u", op: fn, a };
      }
      return { t: "v", n: t.v };
    }
    if (t.k === "op" && t.v === "(") {
      this.eat("(");
      const a = this.add();
      this.eat(")");
      return a;
    }
    throw new Error("Expected a number, column name, or “(“.");
  }
}

export function parseExpression(source: string): ParseResult {
  const trimmed = source.trim();
  if (!trimmed) return { ok: false, message: "Type an expression first." };
  try {
    const { ast, lhs } = new Parser(tokenize(trimmed)).parse();
    return { ok: true, ast, lhs };
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : String(err) };
  }
}

function usedVars(e: UserAst): string[] {
  const s = new Set<string>();
  walk(e, (n) => {
    if (n.t === "v") s.add(n.n);
  });
  return [...s];
}

function walk(e: UserAst, fn: (n: UserAst) => void): void {
  fn(e);
  if (e.t === "u") walk(e.a, fn);
  if (e.t === "b") {
    walk(e.l, fn);
    walk(e.r, fn);
  }
}

function resolve(name: string, columns: string[]): string | null {
  if (columns.includes(name)) return name;
  const lower = name.toLowerCase();
  const hit = columns.filter((c) => c.toLowerCase() === lower);
  if (hit.length === 1) return hit[0]!;
  const snake = name.replace(/-/g, "_");
  const hit2 = columns.filter((c) => c.toLowerCase() === snake.toLowerCase());
  if (hit2.length === 1) return hit2[0]!;
  return null;
}

function evalAst(e: UserAst, row: number[], idx: Map<string, number>): number {
  switch (e.t) {
    case "c":
      return e.v;
    case "v": {
      const j = idx.get(e.n);
      return j == null ? NaN : row[j]!;
    }
    case "u": {
      const a = evalAst(e.a, row, idx);
      switch (e.op) {
        case "neg":
          return -a;
        case "exp":
          return Math.exp(Math.min(20, Math.max(-20, a)));
        case "log":
          return a > 0 ? Math.log(a) : NaN;
        case "log1p":
          return a > -1 ? Math.log1p(a) : NaN;
        case "square":
          return a * a;
        case "sqrt":
          return a >= 0 ? Math.sqrt(a) : NaN;
        case "abs":
          return Math.abs(a);
      }
    }
    case "b": {
      const l = evalAst(e.l, row, idx);
      const r = evalAst(e.r, row, idx);
      switch (e.op) {
        case "+":
          return l + r;
        case "-":
          return l - r;
        case "*":
          return l * r;
        case "/":
          return r === 0 ? NaN : l / r;
        case "^":
          return l < 0 && Math.abs(r % 1) > 1e-12 ? NaN : l ** r;
      }
    }
  }
}

export function prettyAst(e: UserAst): string {
  switch (e.t) {
    case "c":
      return formatConst(e.v);
    case "v":
      return e.n;
    case "u":
      if (e.op === "neg") return `-${wrapUnary(e.a)}`;
      if (e.op === "square") return `${wrapPow(e.a)}^{2}`;
      if (e.op === "sqrt") return `sqrt(${prettyAst(e.a)})`;
      return `${e.op}(${prettyAst(e.a)})`;
    case "b": {
      if (e.op === "^") return `${wrapPow(e.l)}^{${prettyAst(e.r)}}`;
      if (e.op === "*") return `${prettyAst(e.l)} · ${prettyAst(e.r)}`;
      if (e.op === "/") return `${wrapAdd(e.l)} / ${wrapAdd(e.r)}`;
      return `${prettyAst(e.l)} ${e.op} ${prettyAst(e.r)}`;
    }
  }
}

function wrapUnary(e: UserAst): string {
  if (e.t === "b") return `(${prettyAst(e)})`;
  return prettyAst(e);
}
function wrapPow(e: UserAst): string {
  if (e.t === "b" || (e.t === "u" && e.op === "neg")) return `(${prettyAst(e)})`;
  return prettyAst(e);
}
function wrapAdd(e: UserAst): string {
  if (e.t === "b" && (e.op === "+" || e.op === "-")) return `(${prettyAst(e)})`;
  return prettyAst(e);
}
function formatConst(v: number): string {
  if (!Number.isFinite(v)) return "NaN";
  const s = v.toPrecision(6);
  return String(Number(s));
}

export function exampleFor(columns: string[], target: string): string {
  if (columns.includes("Re") && columns.includes("Pr") && target === "Nu") {
    return "0.023 * Re^0.8 * Pr^0.4";
  }
  if (columns.includes("x0") && columns.includes("x1") && columns.includes("x2") && target === "y") {
    return "2.5*x0 + x1*x2";
  }
  const feats = columns.filter((c) => c !== target);
  if (feats.length >= 2) return `0.5 * ${feats[0]} + ${feats[1]}`;
  if (feats[0]) return feats[0];
  return "0";
}

export function scoreUserExpression(source: string, table: DataTable, target: string): UserScore {
  const parsed = parseExpression(source);
  if (!parsed.ok) {
    return emptyScore(source, parsed.message);
  }
  const names = usedVars(parsed.ast);
  const resolved = new Map<string, string>();
  const missing: string[] = [];
  for (const n of names) {
    const hit = resolve(n, table.columns);
    if (!hit) missing.push(n);
    else resolved.set(n, hit);
  }
  if (missing.length) {
    return emptyScore(
      source,
      `Unknown column${missing.length > 1 ? "s" : ""} ${missing.map((m) => `“${m}”`).join(", ")}. Known: ${table.columns.join(", ")}.`,
    );
  }

  const remapped = remap(parsed.ast, resolved);
  const used = [...new Set([...resolved.values()])].sort();
  const idx = new Map(table.columns.map((c, j) => [c, j]));
  const tIdx = table.columns.indexOf(target);
  if (tIdx < 0) return emptyScore(source, `Target “${target}” is not in the table.`);

  const pred: number[] = [];
  const y: number[] = [];
  let mae = 0;
  for (const row of table.rows) {
    const p = evalAst(remapped, row, idx);
    const yi = row[tIdx]!;
    if (!Number.isFinite(p) || !Number.isFinite(yi)) continue;
    pred.push(p);
    y.push(yi);
    mae += Math.abs(p - yi);
  }
  const nFinite = pred.length;
  if (nFinite < 8) {
    return emptyScore(source, `Only ${nFinite} finite predictions — check logs of non-positive values.`);
  }
  mae /= nFinite;
  const pretty = prettyAst(remapped);
  return {
    source,
    pretty: parsed.lhs ? `${parsed.lhs} = ${pretty}` : `${target} = ${pretty}`,
    lhs: parsed.lhs,
    used,
    r2: r2Score(pred, y),
    mse: mse(pred, y),
    mae,
    n: table.rows.length,
    nFinite,
    usesTarget: used.includes(target),
  };
}

function remap(e: UserAst, names: Map<string, string>): UserAst {
  switch (e.t) {
    case "c":
      return e;
    case "v":
      return { t: "v", n: names.get(e.n) ?? e.n };
    case "u":
      return { t: "u", op: e.op, a: remap(e.a, names) };
    case "b":
      return { t: "b", op: e.op, l: remap(e.l, names), r: remap(e.r, names) };
  }
}

function emptyScore(source: string, error: string): UserScore {
  return {
    source,
    pretty: source,
    lhs: null,
    used: [],
    r2: NaN,
    mse: NaN,
    mae: NaN,
    n: 0,
    nFinite: 0,
    usesTarget: false,
    error,
  };
}

/** Convert a parsed user/PySR expression into the GP `Expr` tree. */
export function astToExpr(ast: UserAst, names: string[]): Expr {
  const idx = new Map(names.map((n, i) => [n, i]));
  const conv = (e: UserAst): Expr => {
    switch (e.t) {
      case "c":
        return { t: "c", v: e.v };
      case "v": {
        const i = idx.get(e.n);
        if (i == null) {
          const lower = e.n.toLowerCase();
          const hit = names.findIndex((n) => n.toLowerCase() === lower);
          if (hit < 0) throw new Error(`Unknown variable ${e.n}`);
          return { t: "v", i: hit, n: names[hit]! };
        }
        return { t: "v", i, n: e.n };
      }
      case "u": {
        if (e.op === "neg") return { t: "b", op: "*", l: { t: "c", v: -1 }, r: conv(e.a) };
        if (e.op === "square" || e.op === "exp") return { t: "u", op: e.op, a: conv(e.a) };
        throw new Error(`Operator ${e.op} is not in the engine vocabulary.`);
      }
      case "b": {
        if (e.op === "^") {
          const r = e.r;
          if (r.t === "c" && Math.abs(r.v - 2) < 1e-12) return { t: "u", op: "square", a: conv(e.l) };
          throw new Error("Power other than ² is not in the engine vocabulary.");
        }
        return { t: "b", op: e.op, l: conv(e.l), r: conv(e.r) };
      }
    }
  };
  return conv(ast);
}

export function parseToExpr(source: string, names: string[]): Expr {
  const parsed = parseExpression(source);
  if (!parsed.ok) throw new Error(parsed.message);
  return astToExpr(parsed.ast, names);
}

