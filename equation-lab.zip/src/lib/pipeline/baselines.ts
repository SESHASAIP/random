import { ols, r2Score } from "./linalg.ts";
import { fitBoostedTrees, predictBoostedTrees } from "./trees.ts";

export function predictLinear(X: number[][], y: number[], Xte: number[][]): number[] {
  const design = X.map((row) => [1, ...row]);
  const coef = ols(design, y);
  if (!coef) return Xte.map(() => y.reduce((a, b) => a + b, 0) / y.length);
  return Xte.map((row) => {
    let s = coef[0]!;
    for (let j = 0; j < row.length; j++) s += coef[j + 1]! * row[j]!;
    return s;
  });
}

export function poly2(row: number[]): number[] {
  const out = [...row];
  for (let i = 0; i < row.length; i++) {
    for (let j = i; j < row.length; j++) out.push(row[i]! * row[j]!);
  }
  return out;
}

export function predictRidgePoly2(X: number[][], y: number[], Xte: number[][], lambda = 1e-2): number[] {
  const Xp = X.map(poly2);
  const Xpte = Xte.map(poly2);
  const design = Xp.map((row) => [1, ...row]);
  const coef = ols(design, y, lambda);
  if (!coef) return Xte.map(() => y.reduce((a, b) => a + b, 0) / y.length);
  return Xpte.map((row) => {
    let s = coef[0]!;
    for (let j = 0; j < row.length; j++) s += coef[j + 1]! * row[j]!;
    return s;
  });
}

export function predictHgb(X: number[][], y: number[], Xte: number[][]): number[] {
  const model = fitBoostedTrees(X, y, { nTrees: 36, maxDepth: 3, learningRate: 0.1, nBins: 8 });
  return predictBoostedTrees(model, Xte);
}

export function foldR2(
  predict: (Xtr: number[][], ytr: number[], Xte: number[][]) => number[],
  X: number[][],
  y: number[],
  folds: number[][],
): { mean: number; std: number; folds: number[] } {
  const scores: number[] = [];
  for (let k = 0; k < folds.length; k++) {
    const test = folds[k]!;
    const train: number[] = [];
    for (let j = 0; j < folds.length; j++) if (j !== k) train.push(...folds[j]!);
    const Xtr = train.map((i) => X[i]!);
    const ytr = train.map((i) => y[i]!);
    const Xte = test.map((i) => X[i]!);
    const yte = test.map((i) => y[i]!);
    const pred = predict(Xtr, ytr, Xte);
    scores.push(r2Score(pred, yte));
  }
  const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
  const var_ = scores.reduce((s, v) => s + (v - mean) ** 2, 0) / scores.length;
  return { mean, std: Math.sqrt(var_), folds: scores };
}

export function toRowMajor(cols: Float64Array[]): number[][] {
  const n = cols[0]?.length ?? 0;
  const p = cols.length;
  const out: number[][] = Array.from({ length: n }, () => Array(p).fill(0));
  for (let j = 0; j < p; j++) {
    const col = cols[j]!;
    for (let i = 0; i < n; i++) out[i]![j] = col[i]!;
  }
  return out;
}
