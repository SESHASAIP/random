import type { BinaryOp, UnaryOp } from "./ops.ts";
import { mse } from "./linalg.ts";
import type { Rng } from "./rng.ts";
import { choice, randint } from "./rng.ts";

export type Expr =
  | { t: "c"; v: number }
  | { t: "v"; i: number; n: string }
  | { t: "u"; op: UnaryOp; a: Expr }
  | { t: "b"; op: BinaryOp; l: Expr; r: Expr };

export function complexity(e: Expr): number {
  switch (e.t) {
    case "c":
    case "v":
      return 1;
    case "u":
      return 1 + complexity(e.a);
    case "b":
      return 1 + complexity(e.l) + complexity(e.r);
  }
}

export function clone(e: Expr): Expr {
  switch (e.t) {
    case "c":
      return { t: "c", v: e.v };
    case "v":
      return { t: "v", i: e.i, n: e.n };
    case "u":
      return { t: "u", op: e.op, a: clone(e.a) };
    case "b":
      return { t: "b", op: e.op, l: clone(e.l), r: clone(e.r) };
  }
}

export function usedFeatures(e: Expr): string[] {
  const s = new Set<string>();
  walk(e, (n) => {
    if (n.t === "v") s.add(n.n);
  });
  return [...s].sort();
}

export function usedIndices(e: Expr): number[] {
  const s = new Set<number>();
  walk(e, (n) => {
    if (n.t === "v") s.add(n.i);
  });
  return [...s].sort((a, b) => a - b);
}

export function walk(e: Expr, fn: (n: Expr) => void): void {
  fn(e);
  if (e.t === "u") walk(e.a, fn);
  if (e.t === "b") {
    walk(e.l, fn);
    walk(e.r, fn);
  }
}

export function collectNodes(e: Expr): Expr[] {
  const out: Expr[] = [];
  walk(e, (n) => out.push(n));
  return out;
}

export function mapExpr(e: Expr, fn: (n: Expr) => Expr): Expr {
  const mapped = (() => {
    switch (e.t) {
      case "c":
      case "v":
        return e;
      case "u":
        return { t: "u" as const, op: e.op, a: mapExpr(e.a, fn) };
      case "b":
        return { t: "b" as const, op: e.op, l: mapExpr(e.l, fn), r: mapExpr(e.r, fn) };
    }
  })();
  return fn(mapped);
}

export function evalScalar(e: Expr, x: ArrayLike<number>): number {
  switch (e.t) {
    case "c":
      return e.v;
    case "v":
      return x[e.i]!;
    case "u": {
      const a = evalScalar(e.a, x);
      if (e.op === "square") return a * a;
      return Math.exp(clamp(a, -20, 20));
    }
    case "b": {
      const l = evalScalar(e.l, x);
      const r = evalScalar(e.r, x);
      switch (e.op) {
        case "+":
          return l + r;
        case "-":
          return l - r;
        case "*":
          return l * r;
        case "/":
          return Math.abs(r) < 1e-12 ? 1e6 * Math.sign(l || 1) : l / r;
      }
    }
  }
}

export function evalAll(e: Expr, cols: Float64Array[]): Float64Array {
  const n = cols[0]?.length ?? 0;
  const out = new Float64Array(n);
  evalInto(e, cols, out);
  return out;
}

function evalInto(e: Expr, cols: Float64Array[], out: Float64Array): void {
  const n = out.length;
  switch (e.t) {
    case "c": {
      const v = e.v;
      for (let i = 0; i < n; i++) out[i] = v;
      return;
    }
    case "v": {
      const col = cols[e.i]!;
      out.set(col);
      return;
    }
    case "u": {
      evalInto(e.a, cols, out);
      if (e.op === "square") {
        for (let i = 0; i < n; i++) out[i] = out[i]! * out[i]!;
      } else {
        for (let i = 0; i < n; i++) out[i] = Math.exp(clamp(out[i]!, -20, 20));
      }
      return;
    }
    case "b": {
      const left = new Float64Array(n);
      const right = new Float64Array(n);
      evalInto(e.l, cols, left);
      evalInto(e.r, cols, right);
      switch (e.op) {
        case "+":
          for (let i = 0; i < n; i++) out[i] = left[i]! + right[i]!;
          return;
        case "-":
          for (let i = 0; i < n; i++) out[i] = left[i]! - right[i]!;
          return;
        case "*":
          for (let i = 0; i < n; i++) out[i] = left[i]! * right[i]!;
          return;
        case "/":
          for (let i = 0; i < n; i++) {
            const r = right[i]!;
            out[i] = Math.abs(r) < 1e-12 ? 1e6 * Math.sign(left[i] || 1) : left[i]! / r;
          }
          return;
      }
    }
  }
}

export function lossOf(e: Expr, cols: Float64Array[], y: Float64Array): number {
  return mse(evalAll(e, cols), y);
}

export function toStringExpr(e: Expr, sig = 4): string {
  return render(e, sig, 0);
}

function render(e: Expr, sig: number, prec: number): string {
  const wrap = (s: string, p: number) => (p < prec ? `(${s})` : s);
  switch (e.t) {
    case "c":
      return formatNum(e.v, sig);
    case "v":
      return e.n;
    case "u":
      if (e.op === "square") return wrap(`${render(e.a, sig, 3)}²`, 3);
      return `exp(${render(e.a, sig, 0)})`;
    case "b": {
      const opPrec = e.op === "+" || e.op === "-" ? 1 : 2;
      const l = render(e.l, sig, opPrec);
      const r = render(e.r, sig, e.op === "-" || e.op === "/" ? opPrec + 1 : opPrec);
      const op = e.op === "*" ? "·" : ` ${e.op} `;
      if (e.op === "*") {
        if (e.l.t === "c" && e.r.t === "v") return wrap(`${formatNum(e.l.v, sig)}·${e.r.n}`, opPrec);
      }
      return wrap(`${l}${op}${r}`, opPrec);
    }
  }
}

export function toLatex(e: Expr, sig = 4): string {
  switch (e.t) {
    case "c":
      return formatNum(e.v, sig);
    case "v":
      return `\\mathrm{${e.n}}`;
    case "u":
      if (e.op === "square") return `{${toLatex(e.a, sig)}}^{2}`;
      return `\\exp\\left(${toLatex(e.a, sig)}\\right)`;
    case "b": {
      if (e.op === "/") return `\\frac{${toLatex(e.l, sig)}}{${toLatex(e.r, sig)}}`;
      if (e.op === "*") return `${toLatex(e.l, sig)} \\cdot ${toLatex(e.r, sig)}`;
      const op = e.op === "+" ? " + " : " - ";
      return `${toLatex(e.l, sig)}${op}${toLatex(e.r, sig)}`;
    }
  }
}

export function formatNum(v: number, sig = 4): string {
  if (!Number.isFinite(v)) return "NaN";
  if (Object.is(v, -0)) return "0";
  const a = Math.abs(v);
  if (a !== 0 && (a >= 1e4 || a < 1e-3)) return v.toExponential(sig - 1);
  const s = v.toPrecision(sig);
  return String(Number(s));
}

export function roundConsts(e: Expr, decimals: number): Expr {
  const f = 10 ** decimals;
  return mapExpr(e, (n) => {
    if (n.t === "c") return { t: "c", v: Math.round(n.v * f) / f };
    return n;
  });
}

/** Flatten +/* , sort commutative children, round constants. */
export function canonicalize(e: Expr): Expr {
  return sortComm(simplify(roundConsts(e, 3)));
}

export function srepr(e: Expr): string {
  switch (e.t) {
    case "c":
      return `c:${e.v}`;
    case "v":
      return `v:${e.n}`;
    case "u":
      return `${e.op}(${srepr(e.a)})`;
    case "b":
      return `${e.op}(${srepr(e.l)},${srepr(e.r)})`;
  }
}

export function canonicalKey(e: Expr): { features: string[]; key: string } {
  const c = canonicalize(e);
  return { features: usedFeatures(c), key: srepr(c) };
}

export function simplify(e: Expr): Expr {
  switch (e.t) {
    case "c":
    case "v":
      return e;
    case "u": {
      const a = simplify(e.a);
      if (a.t === "c") {
        if (e.op === "square") return { t: "c", v: a.v * a.v };
        return { t: "c", v: Math.exp(clamp(a.v, -20, 20)) };
      }
      return { t: "u", op: e.op, a };
    }
    case "b": {
      const l = simplify(e.l);
      const r = simplify(e.r);
      if (l.t === "c" && r.t === "c") {
        const v = evalScalar({ t: "b", op: e.op, l, r }, []);
        if (Number.isFinite(v)) return { t: "c", v };
      }
      if (e.op === "+" && r.t === "c" && Math.abs(r.v) < 1e-12) return l;
      if (e.op === "+" && l.t === "c" && Math.abs(l.v) < 1e-12) return r;
      if (e.op === "*" && ((l.t === "c" && Math.abs(l.v) < 1e-12) || (r.t === "c" && Math.abs(r.v) < 1e-12)))
        return { t: "c", v: 0 };
      if (e.op === "*" && l.t === "c" && Math.abs(l.v - 1) < 1e-12) return r;
      if (e.op === "*" && r.t === "c" && Math.abs(r.v - 1) < 1e-12) return l;
      if (e.op === "-" && r.t === "c" && Math.abs(r.v) < 1e-12) return l;
      if (e.op === "/" && r.t === "c" && Math.abs(r.v - 1) < 1e-12) return l;
      return { t: "b", op: e.op, l, r };
    }
  }
}

function sortComm(e: Expr): Expr {
  if (e.t === "u") return { t: "u", op: e.op, a: sortComm(e.a) };
  if (e.t !== "b") return e;
  const l = sortComm(e.l);
  const r = sortComm(e.r);
  if (e.op === "+" || e.op === "*") {
    const terms = flatten(e.op, { t: "b", op: e.op, l, r });
    terms.sort((a, b) => srepr(a).localeCompare(srepr(b)));
    return unflatten(e.op, terms);
  }
  return { t: "b", op: e.op, l, r };
}

function flatten(op: BinaryOp, e: Expr): Expr[] {
  if (e.t === "b" && e.op === op) return [...flatten(op, e.l), ...flatten(op, e.r)];
  return [e];
}

function unflatten(op: BinaryOp, terms: Expr[]): Expr {
  let acc = terms[0]!;
  for (let i = 1; i < terms.length; i++) acc = { t: "b", op, l: acc, r: terms[i]! };
  return acc;
}

export function renameVars(e: Expr, names: string[]): Expr {
  return mapExpr(e, (n) => {
    if (n.t === "v") return { t: "v", i: n.i, n: names[n.i] ?? n.n };
    return n;
  });
}

export function collectConstants(e: Expr): { expr: Expr; values: number[] } {
  const values: number[] = [];
  const expr = mapExpr(clone(e), (n) => {
    if (n.t === "c") {
      const idx = values.length;
      values.push(n.v);
      return { t: "c", v: idx }; // stash index in v temporarily — we'll replace
    }
    return n;
  });
  // The map above overwrote constants with their indices. Rebuild with a holder.
  // Simpler approach: walk and record pointers via a second clone that we mutate.
  return { expr, values };
}

export function withConstants(e: Expr, values: number[]): Expr {
  let k = 0;
  return mapExpr(clone(e), (n) => {
    if (n.t === "c") {
      const v = values[k++] ?? n.v;
      return { t: "c", v };
    }
    return n;
  });
}

export function extractConstants(e: Expr): number[] {
  const out: number[] = [];
  walk(e, (n) => {
    if (n.t === "c") out.push(n.v);
  });
  return out;
}

export function randomConst(rng: Rng): Expr {
  // Mix small integers and reals
  if (rng() < 0.4) return { t: "c", v: randint(rng, -3, 4) };
  return { t: "c", v: (rng() * 4 - 2) * (rng() < 0.3 ? 10 : 1) };
}

export function randomVar(rng: Rng, names: string[]): Expr {
  const i = randint(rng, 0, names.length);
  return { t: "v", i, n: names[i]! };
}

export function randomTree(
  rng: Rng,
  names: string[],
  binops: BinaryOp[],
  unops: UnaryOp[],
  maxDepth: number,
): Expr {
  if (maxDepth <= 1 || rng() < 0.3) {
    return rng() < 0.55 ? randomVar(rng, names) : randomConst(rng);
  }
  if (unops.length && rng() < 0.25) {
    return { t: "u", op: choice(rng, unops), a: randomTree(rng, names, binops, unops, maxDepth - 1) };
  }
  return {
    t: "b",
    op: choice(rng, binops),
    l: randomTree(rng, names, binops, unops, maxDepth - 1),
    r: randomTree(rng, names, binops, unops, maxDepth - 1),
  };
}

export function replaceRandomSubtree(root: Expr, rng: Rng, replacement: Expr): Expr {
  const nodes = collectNodes(root);
  const target = nodes[randint(rng, 0, nodes.length)]!;
  return replaceNode(root, target, replacement);
}

export function replaceNode(root: Expr, target: Expr, replacement: Expr): Expr {
  if (root === target) return replacement;
  if (root.t === "u") return { t: "u", op: root.op, a: replaceNode(root.a, target, replacement) };
  if (root.t === "b") {
    return {
      t: "b",
      op: root.op,
      l: replaceNode(root.l, target, replacement),
      r: replaceNode(root.r, target, replacement),
    };
  }
  return root;
}

export function pickSubtree(root: Expr, rng: Rng): Expr {
  const nodes = collectNodes(root);
  return nodes[randint(rng, 0, nodes.length)]!;
}

function clamp(x: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, x));
}

/** Affine extractor: c0 + Σ ci * var_i  (+ optional products of two vars). */
export type AffineTerm = { coef: number; vars: string[] };

export function asAffine(e: Expr): AffineTerm[] | null {
  const terms = flattenSum(simplify(e));
  const out: AffineTerm[] = [];
  for (const term of terms) {
    const parsed = parseProduct(term);
    if (!parsed) return null;
    out.push(parsed);
  }
  return out;
}

function flattenSum(e: Expr): Expr[] {
  if (e.t === "b" && e.op === "+") return [...flattenSum(e.l), ...flattenSum(e.r)];
  if (e.t === "b" && e.op === "-" ) return [...flattenSum(e.l), neg(e.r)];
  return [e];
}

function neg(e: Expr): Expr {
  return { t: "b", op: "*", l: { t: "c", v: -1 }, r: e };
}

function parseProduct(e: Expr): AffineTerm | null {
  const factors = flattenProd(e);
  let coef = 1;
  const vars: string[] = [];
  for (const f of factors) {
    if (f.t === "c") coef *= f.v;
    else if (f.t === "v") vars.push(f.n);
    else return null;
  }
  vars.sort();
  return { coef, vars };
}

function flattenProd(e: Expr): Expr[] {
  if (e.t === "b" && e.op === "*") return [...flattenProd(e.l), ...flattenProd(e.r)];
  if (e.t === "u" && e.op === "square" && e.a.t === "v") return [e.a, e.a];
  return [e];
}

export function affineToExpr(terms: AffineTerm[], names: string[]): Expr {
  const nameIndex = new Map(names.map((n, i) => [n, i]));
  const parts: Expr[] = [];
  for (const term of terms) {
    if (Math.abs(term.coef) < 1e-12) continue;
    let node: Expr = { t: "c", v: term.coef };
    for (const v of term.vars) {
      const i = nameIndex.get(v) ?? 0;
      node = { t: "b", op: "*", l: node, r: { t: "v", i, n: v } };
    }
    parts.push(node);
  }
  if (parts.length === 0) return { t: "c", v: 0 };
  return unflatten("+", parts);
}

export function add(l: Expr, r: Expr): Expr {
  return { t: "b", op: "+", l, r };
}
export function mul(l: Expr, r: Expr): Expr {
  return { t: "b", op: "*", l, r };
}
export function cnst(v: number): Expr {
  return { t: "c", v };
}
export function vbl(i: number, n: string): Expr {
  return { t: "v", i, n };
}
