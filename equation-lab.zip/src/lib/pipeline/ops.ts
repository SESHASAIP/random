export type BinaryOp = "+" | "-" | "*" | "/";
export type UnaryOp = "exp" | "square";
