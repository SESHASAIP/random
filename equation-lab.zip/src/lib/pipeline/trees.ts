/** Tiny gradient-boosted trees — nonparametric noise ceiling, not the product. */

export type TreeNode =
  | { kind: "leaf"; value: number }
  | { kind: "split"; feature: number; threshold: number; left: TreeNode; right: TreeNode };

export type BoostedModel = {
  base: number;
  learningRate: number;
  trees: TreeNode[];
};

export type BoostedOpts = {
  nTrees: number;
  maxDepth: number;
  learningRate: number;
  nBins: number;
};

export function fitBoostedTrees(X: number[][], y: number[], opts: BoostedOpts): BoostedModel {
  const n = y.length;
  const base = y.reduce((a, b) => a + b, 0) / Math.max(n, 1);
  const residual = y.map((v) => v - base);
  const trees: TreeNode[] = [];
  for (let t = 0; t < opts.nTrees; t++) {
    const tree = fitTree(X, residual, opts.maxDepth, opts.nBins, 0);
    trees.push(tree);
    for (let i = 0; i < n; i++) residual[i]! -= opts.learningRate * predictTree(tree, X[i]!);
  }
  return { base, learningRate: opts.learningRate, trees };
}

export function predictBoostedTrees(model: BoostedModel, X: number[][]): number[] {
  return X.map((row) => {
    let s = model.base;
    for (const tree of model.trees) s += model.learningRate * predictTree(tree, row);
    return s;
  });
}

function predictTree(node: TreeNode, row: number[]): number {
  if (node.kind === "leaf") return node.value;
  return row[node.feature]! <= node.threshold
    ? predictTree(node.left, row)
    : predictTree(node.right, row);
}

function fitTree(X: number[][], y: number[], maxDepth: number, nBins: number, depth: number): TreeNode {
  const n = y.length;
  const mean = y.reduce((a, b) => a + b, 0) / Math.max(n, 1);
  if (depth >= maxDepth || n < 8) return { kind: "leaf", value: mean };

  const p = X[0]?.length ?? 0;
  let bestGain = 0;
  let bestFeat = 0;
  let bestThr = 0;
  const varAll = sse(y);
  for (let f = 0; f < p; f++) {
    const vals = X.map((r) => r[f]!);
    const lo = Math.min(...vals);
    const hi = Math.max(...vals);
    if (!(hi > lo)) continue;
    for (let b = 1; b < nBins; b++) {
      const thr = lo + ((hi - lo) * b) / nBins;
      const left: number[] = [];
      const right: number[] = [];
      for (let i = 0; i < n; i++) {
        if (vals[i]! <= thr) left.push(y[i]!);
        else right.push(y[i]!);
      }
      if (left.length < 4 || right.length < 4) continue;
      const gain = varAll - sse(left) - sse(right);
      if (gain > bestGain) {
        bestGain = gain;
        bestFeat = f;
        bestThr = thr;
      }
    }
  }
  if (bestGain <= 1e-12) return { kind: "leaf", value: mean };

  const leftX: number[][] = [];
  const leftY: number[] = [];
  const rightX: number[][] = [];
  const rightY: number[] = [];
  for (let i = 0; i < n; i++) {
    if (X[i]![bestFeat]! <= bestThr) {
      leftX.push(X[i]!);
      leftY.push(y[i]!);
    } else {
      rightX.push(X[i]!);
      rightY.push(y[i]!);
    }
  }
  return {
    kind: "split",
    feature: bestFeat,
    threshold: bestThr,
    left: fitTree(leftX, leftY, maxDepth, nBins, depth + 1),
    right: fitTree(rightX, rightY, maxDepth, nBins, depth + 1),
  };
}

function sse(ys: number[]): number {
  if (ys.length === 0) return 0;
  const m = ys.reduce((a, b) => a + b, 0) / ys.length;
  let s = 0;
  for (const v of ys) {
    const d = v - m;
    s += d * d;
  }
  return s;
}
