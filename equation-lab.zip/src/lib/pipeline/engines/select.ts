import type { PipelineConfig } from "../types.ts";
import { describeEngine } from "./base.ts";
import { GPEngine } from "./gp.ts";
import { PySREngine } from "./pysr.ts";
import type { SREngine } from "./base.ts";

export function getEngine(cfg: PipelineConfig): SREngine {
  const used = describeEngine(cfg.engine.backend).used;
  if (used === "pysr") return new PySREngine(cfg.engine);
  return new GPEngine(cfg.engine);
}
