import type { Equation, PipelineConfig } from "../types.ts";
import type { Expr } from "../expr.ts";
import { complexity, toStringExpr } from "../expr.ts";

export abstract class SREngine {
  protected readonly cfg: PipelineConfig["engine"];
  constructor(cfg: PipelineConfig["engine"]) {
    this.cfg = cfg;
  }

  abstract fit(
    X: Float64Array[],
    y: Float64Array,
    featureNames: string[],
    seed: number,
  ): void | Promise<void>;

  abstract paretoFront(): Equation[];

  /**
   * PySR model_selection="best": highest score on the front, where
   * score = (log(prev_loss) - log(loss)) / delta_complexity along the
   * complexity-sorted Pareto curve.
   */
  selectBest(minComplexity = 1): Equation {
    const front = this.paretoFront()
      .filter((e) => e.complexity >= minComplexity)
      .slice()
      .sort((a, b) => a.complexity - b.complexity || a.loss - b.loss);
    if (front.length === 0) {
      throw new Error("Empty Pareto front — engine produced no equations.");
    }
    const scored = scoreFront(front);
    let best = scored[0]!;
    for (const eq of scored) {
      if (eq.score > best.score || (eq.score === best.score && eq.loss < best.loss)) best = eq;
    }
    return best;
  }
}

export function scoreFront(front: Equation[]): Equation[] {
  const sorted = front.slice().sort((a, b) => a.complexity - b.complexity || a.loss - b.loss);
  return sorted.map((eq, i) => {
    if (i === 0) return { ...eq, score: 0 };
    const prev = sorted[i - 1]!;
    const dC = eq.complexity - prev.complexity;
    if (dC <= 0 || prev.loss <= 0 || eq.loss <= 0) return { ...eq, score: 0 };
    const score = (Math.log(prev.loss) - Math.log(eq.loss)) / dC;
    return { ...eq, score: Number.isFinite(score) ? score : 0 };
  });
}

export function makeEquation(expr: Expr, loss: number, names: string[], score = 0): Equation {
  return {
    complexity: complexity(expr),
    loss,
    score,
    expr,
    rawString: toStringExpr(expr),
    featureNames: names,
  };
}

type ProbeCache = { julia: boolean; pysr: boolean; reason: string; at: number };

let probeCache: ProbeCache | null = null;

export function setJuliaProbe(p: { julia: boolean; pysr?: boolean; reason: string }): void {
  probeCache = {
    julia: p.julia,
    pysr: p.pysr ?? p.julia,
    reason: p.reason,
    at: Date.now(),
  };
}

export function juliaAvailable(): boolean {
  return probeCache?.julia === true && probeCache.pysr === true;
}

export function lastProbeReason(): string | null {
  return probeCache?.reason ?? null;
}

export function describeEngine(requested: PipelineConfig["engine"]["backend"]): {
  used: "gp" | "pysr";
  juliaAvailable: boolean;
  reason: string;
} {
  const julia = juliaAvailable();
  if (requested === "pysr" && !julia) {
    return {
      used: "gp",
      juliaAvailable: false,
      reason:
        "PySR was requested but Julia/PySR is not ready. Falling back to the GP engine. Results are not comparable to a PySR run.",
    };
  }
  if (requested === "auto") {
    return {
      used: julia ? "pysr" : "gp",
      juliaAvailable: julia,
      reason: julia
        ? "Julia reachable — using PySR."
        : "Julia backend unavailable — using the GP fallback. Engine choice is logged, never silent.",
    };
  }
  return {
    used: requested === "pysr" ? "pysr" : "gp",
    juliaAvailable: julia,
    reason: requested === "gp" ? "GP engine requested explicitly." : "PySR requested.",
  };
}
