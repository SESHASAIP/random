import type { Equation, PipelineConfig } from "../types.ts";
import type { BinaryOp, UnaryOp } from "../ops.ts";
import type { Expr } from "../expr.ts";
import {
  clone,
  collectNodes,
  complexity,
  cnst,
  evalAll,
  extractConstants,
  lossOf,
  mul,
  pickSubtree,
  randomConst,
  randomTree,
  randomVar,
  replaceNode,
  replaceRandomSubtree,
  usedIndices,
  vbl,
  withConstants,
} from "../expr.ts";
import { ols, r2Score } from "../linalg.ts";
import { choice, mulberry32, randint, sample, type Rng } from "../rng.ts";
import { makeEquation, scoreFront, SREngine } from "./base.ts";

type Individual = { expr: Expr; loss: number; complexity: number };

export class GPEngine extends SREngine {
  private names: string[] = [];
  private pareto = new Map<number, Individual>();
  private lastSeed = 0;

  fit(X: Float64Array[], y: Float64Array, featureNames: string[], seed: number): void {
    this.names = featureNames;
    this.lastSeed = seed;
    this.pareto = new Map();
    const rng = mulberry32(seed);
    const nPop = this.cfg.populations;
    const popSize = this.cfg.populationSize;
    const binops = this.cfg.binaryOperators;
    const unops = this.cfg.unaryOperators;
    const maxsize = this.cfg.maxsize;

    const pops: Individual[][] = [];
    for (let p = 0; p < nPop; p++) {
      const pop: Individual[] = [];
      for (let i = 0; i < popSize; i++) {
        const expr =
          rng() < 0.55
            ? smartTree(rng, X, y, featureNames)
            : randomTree(rng, featureNames, binops, unops, randint(rng, 2, 5));
        pop.push(evalInd(expr, X, y, maxsize));
      }
      pops.push(pop);
    }

    for (const pop of pops) for (const ind of pop) this.consider(ind);

    for (let gen = 0; gen < this.cfg.niterations; gen++) {
      for (let p = 0; p < nPop; p++) {
        const pop = pops[p]!;
        pop.sort((a, b) => fitness(a, this.cfg.parsimony) - fitness(b, this.cfg.parsimony));
        const next: Individual[] = pop.slice(0, 2).map((ind) => ({
          expr: clone(ind.expr),
          loss: ind.loss,
          complexity: ind.complexity,
        }));
        while (next.length < popSize) {
          if (rng() < 0.7) {
            const a = tournament(pop, rng);
            const b = tournament(pop, rng);
            const child = crossover(a.expr, b.expr, rng, maxsize);
            next.push(evalInd(child, X, y, maxsize));
          } else {
            const a = tournament(pop, rng);
            const child = mutate(a.expr, rng, featureNames, binops, unops, maxsize);
            next.push(evalInd(child, X, y, maxsize));
          }
        }
        pops[p] = next;
        for (const ind of next) this.consider(ind);
      }

      if (gen % 5 === 4) {
        for (let p = 0; p < nPop; p++) {
          const src = pops[p]!.slice().sort((a, b) => a.loss - b.loss)[0]!;
          const dest = pops[(p + 1) % nPop]!;
          dest[dest.length - 1] = {
            expr: clone(src.expr),
            loss: src.loss,
            complexity: src.complexity,
          };
        }
      }

      if (gen % 6 === 5) {
        for (const pop of pops) {
          pop.sort((a, b) => a.loss - b.loss);
          for (let k = 0; k < Math.min(3, pop.length); k++) {
            const refined = nelderMead(pop[k]!.expr, X, y, rng);
            pop[k] = evalInd(refined, X, y, maxsize);
            this.consider(pop[k]!);
          }
        }
      }
    }

    // Final constant polish on the whole front
    for (const [c, ind] of [...this.pareto.entries()]) {
      const refined = nelderMead(ind.expr, X, y, rng);
      this.pareto.set(c, evalInd(refined, X, y, maxsize));
    }
  }

  paretoFront(): Equation[] {
    const eqs = [...this.pareto.values()].map((ind) =>
      makeEquation(ind.expr, ind.loss, this.names),
    );
    return scoreFront(eqs);
  }

  lastUsedSeed(): number {
    return this.lastSeed;
  }

  private consider(ind: Individual): void {
    if (!Number.isFinite(ind.loss)) return;
    const prev = this.pareto.get(ind.complexity);
    if (!prev || ind.loss < prev.loss) {
      this.pareto.set(ind.complexity, {
        expr: clone(ind.expr),
        loss: ind.loss,
        complexity: ind.complexity,
      });
    }
  }
}

function fitness(ind: Individual, parsimony: number): number {
  return ind.loss * (1 + parsimony * ind.complexity);
}

function evalInd(expr: Expr, X: Float64Array[], y: Float64Array, maxsize: number): Individual {
  let e = expr;
  if (complexity(e) > maxsize) e = pruneToSize(e, maxsize);
  const loss = lossOf(e, X, y);
  return { expr: e, loss, complexity: complexity(e) };
}

function pruneToSize(e: Expr, maxsize: number): Expr {
  while (complexity(e) > maxsize) {
    if (e.t === "b") e = complexity(e.l) >= complexity(e.r) ? e.l : e.r;
    else if (e.t === "u") e = e.a;
    else break;
  }
  return e;
}

function tournament(pop: Individual[], rng: Rng, k = 3): Individual {
  let best = pop[randint(rng, 0, pop.length)]!;
  for (let i = 1; i < k; i++) {
    const cand = pop[randint(rng, 0, pop.length)]!;
    if (cand.loss < best.loss) best = cand;
  }
  return best;
}

function crossover(a: Expr, b: Expr, rng: Rng, maxsize: number): Expr {
  const sub = clone(pickSubtree(b, rng));
  const child = replaceRandomSubtree(clone(a), rng, sub);
  return complexity(child) > maxsize ? clone(a) : child;
}

function mutate(
  expr: Expr,
  rng: Rng,
  names: string[],
  binops: BinaryOp[],
  unops: UnaryOp[],
  maxsize: number,
): Expr {
  const e = clone(expr);
  const kind = rng();
  if (kind < 0.3) {
    const repl = randomTree(rng, names, binops, unops, randint(rng, 1, 3));
    return replaceRandomSubtree(e, rng, repl);
  }
  if (kind < 0.55) {
    const c = pickConst(e, rng);
    if (!c) return replaceRandomSubtree(e, rng, randomVar(rng, names));
    return replaceNode(e, c, { t: "c", v: c.v + (rng() * 2 - 1) * 0.3 });
  }
  if (kind < 0.7) {
    const nodes = collectNodes(e).filter((n) => n.t === "b" || n.t === "u");
    if (nodes.length === 0) return replaceRandomSubtree(e, rng, randomVar(rng, names));
    const n = nodes[randint(rng, 0, nodes.length)]!;
    if (n.t === "b") return replaceNode(e, n, { t: "b", op: choice(rng, binops), l: n.l, r: n.r });
    if (n.t === "u" && unops.length) return replaceNode(e, n, { t: "u", op: choice(rng, unops), a: n.a });
    return e;
  }
  if (kind < 0.85) {
    const sub = pickSubtree(e, rng);
    const wrapped: Expr =
      unops.length && rng() < 0.4
        ? { t: "u", op: choice(rng, unops), a: clone(sub) }
        : rng() < 0.5
          ? { t: "b", op: choice(rng, binops), l: clone(sub), r: rng() < 0.5 ? randomVar(rng, names) : randomConst(rng) }
          : { t: "b", op: choice(rng, binops), l: rng() < 0.5 ? randomVar(rng, names) : randomConst(rng), r: clone(sub) };
    const out = replaceNode(e, sub, wrapped);
    return complexity(out) > maxsize ? e : out;
  }
  const nodes = collectNodes(e);
  const n = nodes[randint(rng, 0, nodes.length)]!;
  if (n.t === "b") return replaceNode(e, n, rng() < 0.5 ? n.l : n.r);
  if (n.t === "u") return replaceNode(e, n, n.a);
  return e;
}

function pickConst(e: Expr, rng: Rng): Extract<Expr, { t: "c" }> | null {
  const cs: Extract<Expr, { t: "c" }>[] = [];
  const walk = (n: Expr) => {
    if (n.t === "c") cs.push(n);
    if (n.t === "u") walk(n.a);
    if (n.t === "b") {
      walk(n.l);
      walk(n.r);
    }
  };
  walk(e);
  if (cs.length === 0) return null;
  return cs[randint(rng, 0, cs.length)]!;
}

/**
 * Seed individuals as OLS on a random 1–3 feature subset, optionally with
 * pairwise products. Seed-dependent, so noise fails the stability gate, but
 * a true low-order relationship is recovered consistently.
 */
function smartTree(rng: Rng, X: Float64Array[], y: Float64Array, names: string[]): Expr {
  const p = names.length;
  const k = Math.min(p, 1 + Math.floor(rng() * 3));
  const idx = sample(rng, Array.from({ length: p }, (_, i) => i), k).sort((a, b) => a - b);
  const interactions = k >= 2 && rng() < 0.55;
  return olsOnSubset(X, y, names, idx, interactions);
}

export function olsOnSubset(
  X: Float64Array[],
  y: Float64Array,
  names: string[],
  idx: number[],
  interactions: boolean,
): Expr {
  const n = y.length;
  const cols: { label: string; values: Float64Array; vars: string[] }[] = [];
  for (const i of idx) {
    cols.push({ label: names[i]!, values: X[i]!, vars: [names[i]!] });
  }
  if (interactions) {
    for (let a = 0; a < idx.length; a++) {
      for (let b = a; b < idx.length; b++) {
        const i = idx[a]!;
        const j = idx[b]!;
        const prod = new Float64Array(n);
        for (let t = 0; t < n; t++) prod[t] = X[i]![t]! * X[j]![t]!;
        const vs = i === j ? [names[i]!, names[i]!] : [names[i]!, names[j]!];
        cols.push({ label: vs.join("*"), values: prod, vars: vs });
      }
    }
  }
  const design: number[][] = [];
  for (let t = 0; t < n; t++) {
    const row = [1];
    for (const c of cols) row.push(c.values[t]!);
    design.push(row);
  }
  const yArr = Array.from(y);
  const coef = ols(design, yArr);
  if (!coef) return cnst(0);
  const terms: Expr[] = [];
  const intercept = coef[0] ?? 0;
  if (Math.abs(intercept) > 1e-8 * (Math.abs(yArr[0] ?? 1) + 1)) terms.push(cnst(intercept));
  for (let c = 0; c < cols.length; c++) {
    const w = coef[c + 1] ?? 0;
    const contrib = Math.abs(w) * rms(cols[c]!.values);
    const ysd = Math.sqrt(varianceOf(y)) + 1e-12;
    if (contrib < 0.02 * ysd) continue;
    if (Math.abs(w) < 1e-8) continue;
    let node: Expr = cnst(w);
    for (const v of cols[c]!.vars) {
      const vi = names.indexOf(v);
      node = mul(node, vbl(vi, v));
    }
    terms.push(node);
  }
  if (terms.length === 0) return cnst(intercept);
  let acc = terms[0]!;
  for (let i = 1; i < terms.length; i++) {
    acc = { t: "b", op: "+", l: acc, r: terms[i]! };
  }
  return acc;
}

function rms(xs: Float64Array): number {
  let s = 0;
  for (let i = 0; i < xs.length; i++) s += xs[i]! * xs[i]!;
  return Math.sqrt(s / xs.length);
}

function varianceOf(y: Float64Array): number {
  let m = 0;
  for (let i = 0; i < y.length; i++) m += y[i]!;
  m /= y.length;
  let s = 0;
  for (let i = 0; i < y.length; i++) {
    const d = y[i]! - m;
    s += d * d;
  }
  return s / y.length;
}

function nelderMead(expr: Expr, X: Float64Array[], y: Float64Array, rng: Rng): Expr {
  const values = extractConstants(expr);
  if (values.length === 0 || values.length > 6) return expr;
  const dim = values.length;
  const lossAt = (theta: number[]) => lossOf(withConstants(expr, theta), X, y);

  const simplex: number[][] = [values.slice()];
  for (let i = 0; i < dim; i++) {
    const v = values.slice();
    v[i] = v[i]! === 0 ? 0.05 : v[i]! * (1.1 + rng() * 0.05);
    simplex.push(v);
  }
  const scores = simplex.map(lossAt);
  const maxIter = 24;
  for (let iter = 0; iter < maxIter; iter++) {
    const order = scores.map((_, i) => i).sort((a, b) => scores[a]! - scores[b]!);
    const best = order[0]!;
    const worst = order[order.length - 1]!;
    const second = order[order.length - 2]!;
    const centroid = Array(dim).fill(0);
    for (let i = 0; i < simplex.length; i++) {
      if (i === worst) continue;
      for (let d = 0; d < dim; d++) centroid[d]! += simplex[i]![d]!;
    }
    for (let d = 0; d < dim; d++) centroid[d]! /= dim;
    const reflected = centroid.map((c, d) => c + (c - simplex[worst]![d]!));
    const fRef = lossAt(reflected);
    if (fRef < scores[best]! ) {
      const expanded = centroid.map((c, d) => c + 2 * (reflected[d]! - c));
      const fExp = lossAt(expanded);
      if (fExp < fRef) {
        simplex[worst] = expanded;
        scores[worst] = fExp;
      } else {
        simplex[worst] = reflected;
        scores[worst] = fRef;
      }
    } else if (fRef < scores[second]!) {
      simplex[worst] = reflected;
      scores[worst] = fRef;
    } else {
      const contracted = centroid.map((c, d) => c + 0.5 * (simplex[worst]![d]! - c));
      const fCon = lossAt(contracted);
      if (fCon < scores[worst]!) {
        simplex[worst] = contracted;
        scores[worst] = fCon;
      } else {
        const bestPt = simplex[best]!;
        for (let i = 0; i < simplex.length; i++) {
          if (i === best) continue;
          simplex[i] = bestPt.map((b, d) => b + 0.5 * (simplex[i]![d]! - b));
          scores[i] = lossAt(simplex[i]!);
        }
      }
    }
  }
  const bestI = scores.map((_, i) => i).sort((a, b) => scores[a]! - scores[b]!)[0]!;
  return withConstants(expr, simplex[bestI]!);
}

export function engineR2(eq: Equation, X: Float64Array[], y: Float64Array): number {
  return r2Score(evalAll(eq.expr, X), y);
}

export function usedFeatureNames(eq: Equation): string[] {
  return usedIndices(eq.expr).map((i) => eq.featureNames[i] ?? `x${i}`);
}
