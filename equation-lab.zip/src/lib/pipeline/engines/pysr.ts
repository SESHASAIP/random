import type { Equation, PipelineConfig } from "../types.ts";
import { evalAll, lossOf } from "../expr.ts";
import { parseToExpr } from "../parse.ts";
import { makeEquation, SREngine } from "./base.ts";

export type PysrEquationRow = {
  complexity: number;
  loss: number;
  score: number;
  sympy: string;
  raw: string;
};

export type PysrResponse = {
  ok: boolean;
  julia?: boolean;
  pysr?: boolean;
  reason?: string;
  error?: string;
  equations?: PysrEquationRow[];
};

type InvokeFn = (payload: Record<string, unknown>) => Promise<PysrResponse>;

let invoke: InvokeFn = invokePysrDefault;

export function setPysrInvoker(fn: InvokeFn): void {
  invoke = fn;
}

export class PySREngine extends SREngine {
  private names: string[] = [];
  private front: Equation[] = [];

  async fit(
    X: Float64Array[],
    y: Float64Array,
    featureNames: string[],
    seed: number,
  ): Promise<void> {
    this.names = featureNames;
    this.front = [];
    const n = y.length;
    const p = featureNames.length;
    const rows: number[][] = Array.from({ length: n }, () => Array(p).fill(0));
    for (let j = 0; j < p; j++) {
      const col = X[j]!;
      for (let i = 0; i < n; i++) rows[i]![j] = col[i]!;
    }
    const res = await invoke({
      cmd: "fit",
      X: rows,
      y: Array.from(y),
      feature_names: featureNames,
      binary_operators: this.cfg.binaryOperators,
      unary_operators: this.cfg.unaryOperators,
      niterations: this.cfg.niterations,
      populations: this.cfg.populations,
      population_size: this.cfg.populationSize,
      maxsize: this.cfg.maxsize,
      parsimony: this.cfg.parsimony,
      seed,
      deterministic: this.cfg.reproducible,
      timeout: this.cfg.niterations > 50 ? 180 : 90,
    });
    if (!res.ok) {
      throw new Error(res.error ?? res.reason ?? "PySR worker failed.");
    }
    const seen = new Map<number, Equation>();
    for (const row of res.equations ?? []) {
      try {
        const expr = parseToExpr(row.sympy || row.raw, featureNames);
        const loss = Number.isFinite(row.loss) ? row.loss : lossOf(expr, X, y);
        const eq = makeEquation(expr, loss, featureNames, row.score ?? 0);
        const prev = seen.get(eq.complexity);
        if (!prev || eq.loss < prev.loss) seen.set(eq.complexity, eq);
      } catch {
        // Skip expressions that use operators outside the GP vocabulary.
      }
    }
    this.front = [...seen.values()].sort((a, b) => a.complexity - b.complexity || a.loss - b.loss);
    if (this.front.length === 0) {
      // Worker returned nothing parseable — keep a constant so selectBest does not throw.
      const pred = evalAll({ t: "c", v: 0 }, X);
      void pred;
      this.front = [makeEquation({ t: "c", v: 0 }, lossOf({ t: "c", v: 0 }, X, y), featureNames)];
    }
  }

  paretoFront(): Equation[] {
    return this.front;
  }
}

async function invokePysrDefault(payload: Record<string, unknown>): Promise<PysrResponse> {
  if (typeof window !== "undefined") {
    const r = await fetch("/api/pysr", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    const json = (await r.json()) as PysrResponse;
    if (!r.ok && !json.error) json.error = `HTTP ${r.status}`;
    return json;
  }
  return spawnPysrWorker(payload);
}

export async function spawnPysrWorker(payload: Record<string, unknown>): Promise<PysrResponse> {
  const { spawn } = await import("node:child_process");
  const { fileURLToPath } = await import("node:url");
  const { dirname, join } = await import("node:path");
  const here = dirname(fileURLToPath(import.meta.url));
  const worker = join(here, "../../../../server/pysr/worker.py");
  return new Promise((resolve, reject) => {
    const child = spawn("python3", [worker], {
      env: {
        ...process.env,
        PYTHON_JULIACALL_HANDLE_SIGNALS: "yes",
        JULIA_NUM_THREADS: "1",
      },
    });
    const chunks: Buffer[] = [];
    const err: Buffer[] = [];
    child.stdout.on("data", (d: Buffer) => chunks.push(d));
    child.stderr.on("data", (d: Buffer) => err.push(d));
    child.on("error", reject);
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("PySR worker timed out."));
    }, Number(payload.timeout ?? 90) * 1000 + 15_000);
    child.on("close", () => {
      clearTimeout(timer);
      const text = Buffer.concat(chunks).toString("utf8").trim();
      if (!text) {
        resolve({
          ok: false,
          error: Buffer.concat(err).toString("utf8").slice(-800) || "empty PySR worker output",
        });
        return;
      }
      try {
        resolve(JSON.parse(text) as PysrResponse);
      } catch {
        resolve({ ok: false, error: text.slice(0, 800) });
      }
    });
    child.stdin.write(JSON.stringify(payload));
    child.stdin.end();
  });
}

export async function probePysr(): Promise<PysrResponse> {
  try {
    return await invoke({ cmd: "probe" });
  } catch (err) {
    return {
      ok: false,
      julia: false,
      pysr: false,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}
