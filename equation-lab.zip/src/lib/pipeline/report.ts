import { toLatex, toStringExpr } from "./expr.ts";
import { backTransformExpr, prettyPowerProduct, Transform } from "./transforms.ts";
import type {
  EngineInfo,
  Equation,
  PipelineConfig,
  PipelineResult,
  ScreeningReport,
  StabilityResult,
  TransformSpec,
  ValidationResult,
} from "./types.ts";
import { configToYaml } from "./config.ts";

export function formatOriginalEquation(
  eq: Equation,
  featureTransforms: TransformSpec[],
  target: TransformSpec,
): { text: string; latex: string; transformed: string } {
  const transformed = toStringExpr(eq.expr);
  const mapping = featureTransforms.map((t) => ({
    original: t.column,
    kind: t.kind,
    transformedName: new Transform(t.kind).prefix(t.column),
  }));
  const back = backTransformExpr(eq.expr, mapping, target.kind);
  const power = prettyPowerProduct(back);
  const lhs = target.column;
  const rhs = power ?? toStringExpr(back);
  const text = `${lhs} = ${rhs}`;
  const latex = `${lhs} = ${power ? powerToLatex(power) : toLatex(back)}`;
  return { text, latex, transformed };
}

function powerToLatex(s: string): string {
  return s
    .replace(/·/g, " \\cdot ")
    .replace(/\^\{([^}]+)\}/g, "^{$1}")
    .replace(/\^([0-9.eE+-]+)/g, "^{$1}");
}

export function buildModelCard(opts: {
  runId: string;
  tableName: string;
  provenance: string;
  nRows: number;
  nFeatures: number;
  cfg: PipelineConfig;
  engine: EngineInfo;
  screening: ScreeningReport;
  transforms: TransformSpec[];
  targetTransform: TransformSpec;
  stability: StabilityResult | null;
  equationText: string | null;
  validation: ValidationResult | null;
  blockedReason: string | null;
}): string {
  const v = opts.stability?.verdict ?? "n/a";
  const lines: string[] = [];
  lines.push(`# Model card — ${opts.runId}`);
  lines.push("");
  lines.push(`**Stability verdict: ${v}**`);
  lines.push("");
  if (opts.blockedReason) {
    lines.push(`> ${opts.blockedReason}`);
    lines.push("");
  }
  if (opts.equationText && v !== "FAIL") {
    lines.push("## Equation");
    lines.push("");
    lines.push("```");
    lines.push(opts.equationText);
    lines.push("```");
    lines.push("");
  }
  lines.push("## Intended use");
  lines.push("");
  lines.push(
    "Discover a short algebraic expression that predicts a continuous target from a small set of continuous features. The deliverable is the equation, not a prediction service. Use it to *propose* a closed form that a reviewer can inspect, not as an automated discovery of physical law.",
  );
  lines.push("");
  lines.push("## Data");
  lines.push("");
  lines.push(`- Source: ${opts.tableName}`);
  lines.push(`- Provenance: ${opts.provenance}`);
  lines.push(`- Rows: ${opts.nRows} · features: ${opts.nFeatures} · target: ${opts.cfg.data.target}`);
  lines.push("");
  lines.push("## Transforms applied");
  lines.push("");
  for (const t of opts.transforms) {
    lines.push(`- \`${t.column}\`: ${t.kind} (${t.source})`);
  }
  lines.push(`- target \`${opts.targetTransform.column}\`: ${opts.targetTransform.kind} (${opts.targetTransform.source})`);
  lines.push("");
  lines.push("## Engine and seeds");
  lines.push("");
  lines.push(`- Requested backend: \`${opts.engine.requested}\``);
  lines.push(`- Used: **${opts.engine.used}**`);
  lines.push(`- ${opts.engine.reason}`);
  lines.push(`- Seeds: ${opts.cfg.stability.nSeeds} (stability), ${opts.cfg.validation.seedsInCv} (nested CV)`);
  lines.push(`- Reproducible: ${opts.cfg.engine.reproducible}`);
  lines.push("");
  if (opts.stability) {
    lines.push("## Stability");
    lines.push("");
    lines.push(`- Verdict: **${opts.stability.verdict}**`);
    lines.push(`- Feature agreement: ${pct(opts.stability.featureAgreement)}`);
    lines.push(`- Structure agreement: ${pct(opts.stability.structureAgreement)}`);
    lines.push(`- Coefficient CV: ${opts.stability.coefCv.toPrecision(3)}`);
    lines.push(`- Complexity IQR: ${opts.stability.complexityIqr}`);
    lines.push("");
    lines.push("| Feature | Frequency |");
    lines.push("|---|---|");
    const freq = Object.entries(opts.stability.featureFrequency).sort((a, b) => b[1] - a[1]);
    for (const [f, p] of freq) lines.push(`| ${f} | ${pct(p)} |`);
    lines.push("");
  }
  if (opts.validation) {
    lines.push("## Nested CV");
    lines.push("");
    if (opts.validation.nestedCvR2Mean == null) {
      lines.push("Nested CV was not run (stability FAIL — no equation to validate).");
    } else {
      lines.push(
        `Headline R² = **${opts.validation.nestedCvR2Mean.toFixed(3)} ± ${opts.validation.nestedCvR2Std?.toFixed(3)}** (outer folds, original units). This is *not* the holdout used to pick the equation off the Pareto front.`,
      );
    }
    lines.push("");
    lines.push("## Baseline gauntlet");
    lines.push("");
    lines.push("| Model | R² mean | R² std |");
    lines.push("|---|---|---|");
    for (const b of opts.validation.baselines) {
      lines.push(`| ${b.name} | ${b.r2Mean.toFixed(3)} | ${b.r2Std.toFixed(3)} |`);
    }
    lines.push("");
    if (opts.validation.beatsTransformedLinear === false) {
      lines.push(
        "SR does **not** beat transformed-linear by a meaningful margin. The log/linear transform is doing the work; the search added nothing you could not have written by hand.",
      );
      lines.push("");
    }
    if (opts.validation.leakageWarning) {
      lines.push(
        "Warning: SR nested-CV R² sits above the boosted-tree noise ceiling. Treat this as a leakage signal, not a win.",
      );
      lines.push("");
    }
  }
  lines.push("## Limitations");
  lines.push("");
  lines.push("- Extrapolation outside the training range is undefined, especially for power laws.");
  lines.push("- The equation is empirical and carries **no mechanistic claim**.");
  lines.push("- Genetic programming is stochastic; an equation that fails the multi-seed gate is not a finding.");
  lines.push("- Reported R² is nested CV. Training loss on the selected equation is optimistic and is not reported as performance.");
  lines.push("");
  lines.push("## Reproduction");
  lines.push("");
  lines.push("```yaml");
  lines.push(configToYaml(opts.cfg).trimEnd());
  lines.push("```");
  lines.push("");
  lines.push(`Run id \`${opts.runId}\`. Seed base ${opts.cfg.validation.randomState}.`);
  return lines.join("\n");
}

export function buildStabilityMarkdown(s: StabilityResult): string {
  const lines = [
    `# Stability`,
    "",
    `**Verdict: ${s.verdict}**`,
    "",
    s.refuseEquation
      ? "The search did not converge on a consistent structure. No equation is emitted. Treat the feature-frequency table as exploratory only."
      : "Seeds agreed on a feature set. The equation below is a finding, not a lucky fit.",
    "",
    `| Metric | Value |`,
    `|---|---|`,
    `| Feature agreement | ${pct(s.featureAgreement)} |`,
    `| Structure agreement | ${pct(s.structureAgreement)} |`,
    `| Coefficient CV | ${s.coefCv.toPrecision(3)} |`,
    `| Complexity IQR | ${s.complexityIqr} |`,
    "",
    "## Feature frequency",
    "",
    "| Feature | Fraction of seeds |",
    "|---|---|",
  ];
  for (const [f, p] of Object.entries(s.featureFrequency).sort((a, b) => b[1] - a[1])) {
    lines.push(`| ${f} | ${pct(p)} |`);
  }
  lines.push("", "## Per seed", "", "| Seed | Features | Complexity | Loss | Equation |", "|---|---|---|---|---|");
  for (const row of s.perSeed) {
    lines.push(
      `| ${row.seed} | ${row.features.join(", ") || "—"} | ${row.complexity} | ${row.loss.toExponential(3)} | \`${row.rawString}\` |`,
    );
  }
  lines.push("");
  return lines.join("\n");
}

export function buildValidationMarkdown(v: ValidationResult): string {
  const lines = ["# Validation", ""];
  if (v.nestedCvR2Mean == null) {
    lines.push("Nested CV skipped.");
  } else {
    lines.push(
      `Headline (nested CV) R² = **${v.nestedCvR2Mean.toFixed(3)} ± ${v.nestedCvR2Std?.toFixed(3)}**.`,
    );
    lines.push("");
    lines.push(`Outer fold R²: ${v.nestedFoldR2.map((x) => x.toFixed(3)).join(", ")}`);
  }
  lines.push("", "## Baselines (identical outer folds, original units)", "");
  lines.push("| Model | R² mean | R² std |", "|---|---|---|");
  for (const b of v.baselines) lines.push(`| ${b.name} | ${b.r2Mean.toFixed(3)} | ${b.r2Std.toFixed(3)} |`);
  lines.push("");
  if (v.holdoutR2 != null) lines.push(`Holdout R² (residuals only, not the headline): ${v.holdoutR2.toFixed(3)}`);
  lines.push("");
  return lines.join("\n");
}

export function buildEquationText(opts: {
  transformed: string;
  original: string;
  latex: string;
  complexity: number;
  loss: number;
}): string {
  return [
    "transformed space:",
    opts.transformed,
    "",
    "original units:",
    opts.original,
    "",
    "latex:",
    opts.latex,
    "",
    `complexity: ${opts.complexity}`,
    `loss (transformed MSE): ${opts.loss}`,
    "",
  ].join("\n");
}

function pct(x: number): string {
  return `${(x * 100).toFixed(0)}%`;
}

export type { PipelineResult };
