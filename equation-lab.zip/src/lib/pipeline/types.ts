import type { Expr } from "./expr.ts";
import type { TransformKind } from "./transforms.ts";
export type { BinaryOp, UnaryOp } from "./ops.ts";
import type { BinaryOp, UnaryOp } from "./ops.ts";

export type EngineBackend = "auto" | "pysr" | "gp";

export type Equation = {
  complexity: number;
  loss: number;
  score: number;
  expr: Expr;
  rawString: string;
  featureNames: string[];
};

export type PipelineConfig = {
  data: {
    target: string;
    features: string[];
    dropDuplicates: boolean;
  };
  transforms: {
    auto: boolean;
    overrides: Record<string, TransformKind>;
  };
  engine: {
    backend: EngineBackend;
    reproducible: boolean;
    binaryOperators: BinaryOp[];
    unaryOperators: UnaryOp[];
    maxsize: number;
    parsimony: number;
    niterations: number;
    populations: number;
    populationSize: number;
  };
  stability: {
    nSeeds: number;
    featureAgreementThreshold: number;
    coefCvThreshold: number;
  };
  validation: {
    outerFolds: number;
    seedsInCv: number;
    testSize: number;
    randomState: number;
  };
};

export type ColumnStats = {
  name: string;
  n: number;
  min: number;
  max: number;
  mean: number;
  std: number;
  nFinite: number;
  nUnique: number;
};

export type DataTable = {
  id: string;
  name: string;
  provenance: string;
  columns: string[];
  /** Row-major numeric matrix, aligned with `columns`. */
  rows: number[][];
  target: string;
  knownEquation?: string;
};

export type ScreeningCheck = {
  name: string;
  ok: boolean;
  level: "pass" | "warn" | "stop";
  message: string;
};

export type ScreeningReport = {
  proceed: boolean;
  nRows: number;
  nFeatures: number;
  target: string;
  features: string[];
  checks: ScreeningCheck[];
  noiseCeilingR2: number | null;
  noiseCeilingNote: string;
};

export type TransformSpec = {
  column: string;
  kind: TransformKind;
  source: "auto" | "override";
};

export type Progress = {
  phase: "screen" | "transform" | "fit" | "stability" | "validate" | "report";
  message: string;
  ratio: number;
};

export type GateVerdict = "PASS" | "MARGINAL" | "FAIL";

export type StabilityResult = {
  verdict: GateVerdict;
  featureAgreement: number;
  structureAgreement: number;
  coefCv: number;
  complexityIqr: number;
  featureFrequency: Record<string, number>;
  modalFeatures: string[];
  perSeed: {
    seed: number;
    features: string[];
    rawString: string;
    complexity: number;
    loss: number;
  }[];
  refuseEquation: boolean;
};

export type BaselineRow = {
  name: string;
  r2Mean: number;
  r2Std: number;
};

export type ValidationResult = {
  nestedCvR2Mean: number | null;
  nestedCvR2Std: number | null;
  nestedFoldR2: number[];
  baselines: BaselineRow[];
  holdoutR2: number | null;
  beatsTransformedLinear: boolean | null;
  leakageWarning: boolean;
  residualFitted: { fitted: number; residual: number }[];
  residualByFeature: Record<string, { x: number; residual: number }[]>;
  qq: { theoretical: number; sample: number }[];
};

export type EngineInfo = {
  requested: EngineBackend;
  used: "gp" | "pysr";
  juliaAvailable: boolean;
  reason: string;
};

export type PipelineResult = {
  runId: string;
  timestamp: string;
  config: PipelineConfig;
  engine: EngineInfo;
  screening: ScreeningReport;
  transforms: TransformSpec[];
  targetTransform: TransformSpec;
  stability: StabilityResult | null;
  equation: Equation | null;
  originalEquation: string | null;
  originalLatex: string | null;
  validation: ValidationResult | null;
  pareto: { complexity: number; loss: number; score: number; rawString: string }[];
  modelCard: string;
  stabilityMarkdown: string;
  validationMarkdown: string;
  equationText: string;
  blockedReason: string | null;
};

export type DatasetKind = "heat" | "noise" | "tiny" | "additive" | "csv";
