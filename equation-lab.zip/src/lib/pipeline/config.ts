import { z } from "zod";
import type { PipelineConfig } from "./types.ts";

const transformKind = z.enum(["identity", "log", "log1p", "signed_log"]);

export const pipelineConfigSchema = z.object({
  data: z.object({
    target: z.string().min(1),
    features: z.array(z.string()).min(1),
    dropDuplicates: z.boolean(),
  }),
  transforms: z.object({
    auto: z.boolean(),
    overrides: z.record(z.string(), transformKind),
  }),
  engine: z.object({
    backend: z.enum(["auto", "pysr", "gp"]),
    reproducible: z.boolean(),
    binaryOperators: z.array(z.enum(["+", "-", "*", "/"])).min(1),
    unaryOperators: z.array(z.enum(["exp", "square"])),
    maxsize: z.number().int().positive(),
    parsimony: z.number().nonnegative(),
    niterations: z.number().int().positive(),
    populations: z.number().int().positive(),
    populationSize: z.number().int().positive(),
  }),
  stability: z.object({
    nSeeds: z.number().int().positive(),
    featureAgreementThreshold: z.number().min(0).max(1),
    coefCvThreshold: z.number().positive(),
  }),
  validation: z.object({
    outerFolds: z.number().int().min(2),
    seedsInCv: z.number().int().positive(),
    testSize: z.number().gt(0).lt(0.5),
    randomState: z.number().int(),
  }),
});

export function defaultConfig(partial?: {
  target?: string;
  features?: string[];
  thorough?: boolean;
}): PipelineConfig {
  const thorough = partial?.thorough ?? false;
  return pipelineConfigSchema.parse({
    data: {
      target: partial?.target ?? "Nu",
      features: partial?.features ?? ["Re", "Pr", "rough", "T_amb", "wall", "L_over_D"],
      dropDuplicates: true,
    },
    transforms: {
      auto: true,
      overrides: {},
    },
    engine: {
      backend: "auto",
      reproducible: true,
      binaryOperators: ["+", "-", "*", "/"],
      unaryOperators: ["exp", "square"],
      maxsize: 18,
      parsimony: 0.0028,
      niterations: thorough ? 80 : 36,
      populations: thorough ? 12 : 6,
      populationSize: thorough ? 40 : 28,
    },
    stability: {
      nSeeds: thorough ? 7 : 5,
      featureAgreementThreshold: 0.7,
      coefCvThreshold: 0.15,
    },
    validation: {
      outerFolds: thorough ? 5 : 3,
      seedsInCv: thorough ? 3 : 1,
      testSize: 0.3,
      randomState: 1,
    },
  });
}

export function configToYaml(cfg: PipelineConfig): string {
  const overrides =
    Object.keys(cfg.transforms.overrides).length === 0
      ? "{}"
      : `{${Object.entries(cfg.transforms.overrides)
          .map(([k, v]) => `${k}: ${v}`)
          .join(", ")}}`;
  return `data:
  target: ${cfg.data.target}
  features: [${cfg.data.features.join(", ")}]
  drop_duplicates: ${cfg.data.dropDuplicates}

transforms:
  auto: ${cfg.transforms.auto}
  overrides: ${overrides}

engine:
  backend: ${cfg.engine.backend}
  reproducible: ${cfg.engine.reproducible}
  binary_operators: [${cfg.engine.binaryOperators.map((o) => `"${o}"`).join(", ")}]
  unary_operators: [${cfg.engine.unaryOperators.map((o) => `"${o}"`).join(", ")}]
  maxsize: ${cfg.engine.maxsize}
  parsimony: ${cfg.engine.parsimony}
  niterations: ${cfg.engine.niterations}
  populations: ${cfg.engine.populations}
  population_size: ${cfg.engine.populationSize}

stability:
  n_seeds: ${cfg.stability.nSeeds}
  feature_agreement_threshold: ${cfg.stability.featureAgreementThreshold}
  coef_cv_threshold: ${cfg.stability.coefCvThreshold}

validation:
  outer_folds: ${cfg.validation.outerFolds}
  seeds_in_cv: ${cfg.validation.seedsInCv}
  test_size: ${cfg.validation.testSize}
  random_state: ${cfg.validation.randomState}
`;
}
