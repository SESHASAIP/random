import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { generateAdditive, generateNoise, generatePowerLaw, generateTiny } from "./data.ts";
import { recommend, Transform } from "./transforms.ts";
import { columnValues } from "./data.ts";
import { screen } from "./screening.ts";
import { defaultConfig } from "./config.ts";
import { GPEngine } from "./engines/gp.ts";
import { PySREngine } from "./engines/pysr.ts";
import { getEngine } from "./engines/select.ts";
import { describeEngine, setJuliaProbe } from "./engines/base.ts";
import { toColumns } from "./data.ts";
import { applyColumn } from "./transforms.ts";
import { r2Score } from "./linalg.ts";
import { evalAll, usedFeatures } from "./expr.ts";
import { canonicalKey } from "./expr.ts";
import { runStability } from "./stability.ts";
import { previewScreenAndTransforms } from "./pipeline.ts";
import { scoreUserExpression, parseToExpr } from "./parse.ts";

describe("transforms", () => {
  it("inverse(forward(x)) ≈ x to 1e-10", () => {
    const kinds = ["identity", "log", "log1p", "signed_log"] as const;
    const samples: Record<(typeof kinds)[number], number[]> = {
      identity: [-3, -0.2, 0, 0.4, 12, 1e6],
      log: [0.02, 1, 2.5, 80, 1e5],
      log1p: [0, 0.2, 4, 99],
      signed_log: [-400, -1, 0, 1, 400],
    };
    for (const kind of kinds) {
      const t = new Transform(kind);
      for (const x of samples[kind]) {
        const back = t.inverse(t.forward(x));
        assert.ok(Math.abs(back - x) < 1e-10, `${kind} roundtrip failed at ${x}: ${back}`);
      }
    }
  });

  it("recommends log on the power-law inputs and target", () => {
    const table = generatePowerLaw({ n: 400, seed: 1, noise: 0.05 });
    const re = columnValues(table, "Re");
    const pr = columnValues(table, "Pr");
    const nu = columnValues(table, "Nu");
    const tamb = columnValues(table, "T_amb");
    assert.equal(recommend(re), "log");
    assert.equal(recommend(pr), "log");
    assert.equal(recommend(nu), "log");
    assert.equal(recommend(tamb), "identity");
  });
});

describe("screening", () => {
  it("rejects a 50-row dataset by name", () => {
    const table = generateTiny();
    const features = table.columns.filter((c) => c !== table.target);
    const report = screen(table, features, table.target);
    assert.equal(report.proceed, false);
    const rowCheck = report.checks.find((c) => c.name === "n_rows");
    assert.ok(rowCheck);
    assert.equal(rowCheck!.level, "stop");
    assert.match(rowCheck!.message, /n_rows = 50/);
  });

  it("lets the 400-row heat table through", () => {
    const table = generatePowerLaw({ n: 400, seed: 1 });
    const features = table.columns.filter((c) => c !== table.target);
    const report = screen(table, features, table.target);
    assert.equal(report.proceed, true);
  });
});

describe("GP engine", () => {
  it("recovers y = 2.5·x0 + x1·x2 from 300 clean rows", () => {
    const table = generateAdditive({ n: 300, seed: 11 });
    const names = ["x0", "x1", "x2"];
    const X = toColumns(table, names);
    const y = toColumns(table, ["y"])[0]!;
    const engine = new GPEngine({
      backend: "gp",
      reproducible: true,
      binaryOperators: ["+", "-", "*", "/"],
      unaryOperators: ["exp", "square"],
      maxsize: 18,
      parsimony: 0.0028,
      niterations: 28,
      populations: 6,
      populationSize: 28,
    });
    engine.fit(X, y, names, 11);
    const best = engine.selectBest();
    const pred = evalAll(best.expr, X);
    const r2 = r2Score(pred, y);
    assert.ok(r2 > 0.99, `R² ${r2} too low; got ${best.rawString}`);
    const feats = usedFeatures(best.expr);
    for (const f of ["x0", "x1", "x2"]) {
      assert.ok(feats.includes(f), `missing ${f} in ${best.rawString}`);
    }
  });
});

describe("stability gate", () => {
  it("PASSes on clean synthetic power-law data", async () => {
    const table = generatePowerLaw({ n: 320, seed: 1, noise: 0.05 });
    const cfg = defaultConfig({
      target: "Nu",
      features: ["Re", "Pr", "rough", "T_amb", "wall", "L_over_D"],
    });
    cfg.engine.niterations = 18;
    cfg.engine.populations = 5;
    cfg.engine.populationSize = 22;
    cfg.stability.nSeeds = 5;
    const { transforms, targetTransform } = previewScreenAndTransforms(table, cfg);
    const featCols = transforms.map((t) => {
      const raw = columnValues(table, t.column);
      return applyColumn(raw, new Transform(t.kind));
    });
    const y = applyColumn(columnValues(table, "Nu"), new Transform(targetTransform.kind));
    const names = transforms.map((t) => new Transform(t.kind).prefix(t.column));
    const result = await runStability(
      () =>
        new GPEngine(cfg.engine),
      featCols,
      y,
      names,
      cfg,
      [2, 3, 4, 5, 6],
    );
    assert.equal(result.verdict, "PASS", JSON.stringify(result, null, 2));
    assert.equal(result.featureAgreement, 1);
    const modal = result.modalFeatures.map((f) => f.replace(/^ln_/, "")).sort();
    assert.deepEqual(modal, ["Pr", "Re"]);
  });

  it("FAILs on a pure-noise target and emits no equation", async () => {
    const table = generateNoise({ n: 320, seed: 7 });
    const cfg = defaultConfig({
      target: "Nu",
      features: ["Re", "Pr", "rough", "T_amb", "wall", "L_over_D"],
    });
    cfg.engine.niterations = 12;
    cfg.engine.populations = 4;
    cfg.engine.populationSize = 18;
    cfg.stability.nSeeds = 5;
    const featCols = toColumns(table, cfg.data.features);
    const y = toColumns(table, ["Nu"])[0]!;
    const result = await runStability(
      () => new GPEngine(cfg.engine),
      featCols,
      y,
      cfg.data.features,
      cfg,
      [11, 22, 33, 44, 55],
    );
    assert.equal(result.verdict, "FAIL", JSON.stringify({
      verdict: result.verdict,
      fa: result.featureAgreement,
      freq: result.featureFrequency,
    }));
    assert.equal(result.refuseEquation, true);
  });
});

describe("canonicalization", () => {
  it("rounds coefficients before comparing", () => {
    const a = canonicalKey({
      t: "b",
      op: "+",
      l: { t: "b", op: "*", l: { t: "c", v: 2.5004 }, r: { t: "v", i: 0, n: "x0" } },
      r: { t: "b", op: "*", l: { t: "v", i: 1, n: "x1" }, r: { t: "v", i: 2, n: "x2" } },
    });
    const b = canonicalKey({
      t: "b",
      op: "+",
      l: { t: "b", op: "*", l: { t: "v", i: 1, n: "x1" }, r: { t: "v", i: 2, n: "x2" } },
      r: { t: "b", op: "*", l: { t: "c", v: 2.4996 }, r: { t: "v", i: 0, n: "x0" } },
    });
    assert.equal(a.key, b.key);
    assert.deepEqual(a.features, ["x0", "x1", "x2"]);
  });
});

describe("user expression parser", () => {
  it("recovers Dittus–Boelter on the heat table", () => {
    const table = generatePowerLaw({ n: 400, seed: 1, noise: 0.05 });
    const score = scoreUserExpression("0.023 * Re^0.8 * Pr^0.4", table, "Nu");
    assert.equal(score.error, undefined, score.error);
    assert.ok(score.r2 > 0.95, `R² ${score.r2}`);
    assert.deepEqual(score.used, ["Pr", "Re"]);
  });

  it("accepts Nu = … and ** for power", () => {
    const table = generatePowerLaw({ n: 200, seed: 2, noise: 0 });
    const score = scoreUserExpression("Nu = 0.023 * Re**0.8 * Pr**0.4", table, "Nu");
    assert.equal(score.error, undefined, score.error);
    assert.ok(score.r2 > 0.999, `R² ${score.r2}`);
  });

  it("recovers the additive identity", () => {
    const table = generateAdditive({ n: 300, seed: 11 });
    const score = scoreUserExpression("2.5*x0 + x1*x2", table, "y");
    assert.equal(score.error, undefined, score.error);
    assert.ok(Math.abs(score.r2 - 1) < 1e-10, `R² ${score.r2}`);
  });

  it("rejects unknown columns", () => {
    const table = generatePowerLaw({ n: 80, seed: 1 });
    const score = scoreUserExpression("0.023 * foo^0.8", table, "Nu");
    assert.match(score.error ?? "", /Unknown column/);
  });

  it("parses a PySR-style sympy string into an Expr", () => {
    const expr = parseToExpr("2.5*x0 + x1*x2", ["x0", "x1", "x2"]);
    const table = generateAdditive({ n: 40, seed: 3 });
    const X = toColumns(table, ["x0", "x1", "x2"]);
    const y = toColumns(table, ["y"])[0]!;
    const r2 = r2Score(evalAll(expr, X), y);
    assert.ok(Math.abs(r2 - 1) < 1e-10, `R² ${r2}`);
  });
});

describe("engine selection", () => {
  it("auto uses GP when Julia is not probed", () => {
    setJuliaProbe({ julia: false, pysr: false, reason: "test" });
    const cfg = defaultConfig({ target: "y", features: ["x0", "x1", "x2"] });
    cfg.engine.backend = "auto";
    const info = describeEngine("auto");
    assert.equal(info.used, "gp");
    assert.equal(getEngine(cfg) instanceof GPEngine, true);
  });

  it("auto uses PySR when the probe succeeds", () => {
    setJuliaProbe({ julia: true, pysr: true, reason: "test" });
    const cfg = defaultConfig({ target: "y", features: ["x0", "x1", "x2"] });
    cfg.engine.backend = "auto";
    assert.equal(describeEngine("auto").used, "pysr");
    assert.equal(getEngine(cfg) instanceof PySREngine, true);
    setJuliaProbe({ julia: false, pysr: false, reason: "reset" });
  });

  it("requested PySR downgrades to GP when Julia is missing", () => {
    setJuliaProbe({ julia: false, reason: "missing" });
    const info = describeEngine("pysr");
    assert.equal(info.used, "gp");
    assert.match(info.reason, /Falling back/);
  });
});

