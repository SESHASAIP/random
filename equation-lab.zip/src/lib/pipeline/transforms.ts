import { kurtosis } from "./linalg.ts";
import type { Expr } from "./expr.ts";
import { mapExpr } from "./expr.ts";

export type TransformKind = "identity" | "log" | "log1p" | "signed_log";

export class Transform {
  readonly kind: TransformKind;
  constructor(kind: TransformKind) {
    this.kind = kind;
  }

  forward(x: number): number {
    switch (this.kind) {
      case "identity":
        return x;
      case "log":
        return Math.log(x);
      case "log1p":
        return Math.log1p(x);
      case "signed_log":
        return Math.sign(x) * Math.log1p(Math.abs(x));
    }
  }

  inverse(x: number): number {
    switch (this.kind) {
      case "identity":
        return x;
      case "log":
        return Math.exp(x);
      case "log1p":
        return Math.expm1(x);
      case "signed_log":
        return Math.sign(x) * Math.expm1(Math.abs(x));
    }
  }

  prefix(col: string): string {
    switch (this.kind) {
      case "identity":
        return col;
      case "log":
        return `ln_${col}`;
      case "log1p":
        return `log1p_${col}`;
      case "signed_log":
        return `slog_${col}`;
    }
  }

  originalFromPrefix(name: string): string | null {
    switch (this.kind) {
      case "identity":
        return name;
      case "log":
        return name.startsWith("ln_") ? name.slice(3) : null;
      case "log1p":
        return name.startsWith("log1p_") ? name.slice(6) : null;
      case "signed_log":
        return name.startsWith("slog_") ? name.slice(5) : null;
    }
  }
}

export function recommend(col: ArrayLike<number>): TransformKind {
  const n = col.length;
  let min = Infinity;
  let max = -Infinity;
  let hasNeg = false;
  let hasZero = false;
  let hasPos = false;
  const finite: number[] = [];
  for (let i = 0; i < n; i++) {
    const v = col[i]!;
    if (!Number.isFinite(v)) {
      throw new Error("Non-finite value in column; cannot recommend a transform.");
    }
    finite.push(v);
    if (v < min) min = v;
    if (v > max) max = v;
    if (v < 0) hasNeg = true;
    else if (v === 0) hasZero = true;
    else hasPos = true;
  }
  const spread = min !== 0 && Number.isFinite(min) ? max / Math.abs(min) : Infinity;
  const wide = spread > 30 && max > 0;

  if (!hasNeg && !hasZero && hasPos && wide) return "log";
  if (!hasNeg && hasZero && hasPos && wide) return "log1p";
  if (hasNeg && kurtosis(finite) > 8) return "signed_log";
  return "identity";
}

export function applyColumn(values: ArrayLike<number>, t: Transform): Float64Array {
  const out = new Float64Array(values.length);
  for (let i = 0; i < values.length; i++) out[i] = t.forward(values[i]!);
  return out;
}

export function inverseColumn(values: ArrayLike<number>, t: Transform): Float64Array {
  const out = new Float64Array(values.length);
  for (let i = 0; i < values.length; i++) out[i] = t.inverse(values[i]!);
  return out;
}

/**
 * Substitute transformed feature symbols back and invert the target
 * transform symbolically for display.
 */
export function backTransformExpr(
  expr: Expr,
  featureTransforms: { original: string; kind: TransformKind; transformedName: string }[],
  targetKind: TransformKind,
): Expr {
  const byTransformed = new Map(featureTransforms.map((f) => [f.transformedName, f]));

  let substituted = mapExpr(expr, (n) => {
    if (n.t !== "v") return n;
    const spec = byTransformed.get(n.n);
    if (!spec) return n;
    const orig: Expr = { t: "v", i: n.i, n: spec.original };
    if (spec.kind === "identity") return orig;
    if (spec.kind === "log") {
      // ln_x is log(x); keep as unary-log encoded via name, then fold later.
      return { t: "v", i: n.i, n: `log(${spec.original})` };
    }
    if (spec.kind === "log1p") return { t: "v", i: n.i, n: `log1p(${spec.original})` };
    return { t: "v", i: n.i, n: `signed_log(${spec.original})` };
  });

  if (targetKind === "log") {
    substituted = { t: "u", op: "exp", a: substituted };
    substituted = powsimpExpLog(substituted);
  } else if (targetKind === "log1p") {
    // z = expm1(expr) — leave as exp(expr) - 1
    substituted = {
      t: "b",
      op: "-",
      l: { t: "u", op: "exp", a: substituted },
      r: { t: "c", v: 1 },
    };
  }
  return substituted;
}

/**
 * exp(c + a*log(x) + b*log(y)) → exp(c) * x^a * y^b, represented as a
 * pretty product of power-tagged variables (encoded in the name).
 */
function powsimpExpLog(e: Expr): Expr {
  if (e.t !== "u" || e.op !== "exp") return e;
  const terms = flattenAdd(e.a);
  const powers: { name: string; i: number; exp: number }[] = [];
  let intercept = 0;
  const rest: Expr[] = [];
  for (const term of terms) {
    const p = matchALog(term);
    if (p) {
      powers.push(p);
      continue;
    }
    if (term.t === "c") {
      intercept += term.v;
      continue;
    }
    rest.push(term);
  }
  if (rest.length > 0) return e; // not a pure log-linear form
  let node: Expr = { t: "c", v: Math.exp(intercept) };
  for (const p of powers) {
    const factor: Expr =
      Math.abs(p.exp - 1) < 1e-12
        ? { t: "v", i: p.i, n: p.name }
        : {
            t: "b",
            op: "*",
            l: { t: "c", v: 1 },
            r: { t: "v", i: p.i, n: `${p.name}^${round4(p.exp)}` },
          };
    // encode as name^exp variable so the printer shows a power
    const powered: Expr = { t: "v", i: p.i, n: powName(p.name, p.exp) };
    node = { t: "b", op: "*", l: node, r: powered };
    void factor;
  }
  return node;
}

function powName(name: string, exp: number): string {
  if (Math.abs(exp - 1) < 1e-12) return name;
  return `${name}^{${round4(exp)}}`;
}

function round4(x: number): number {
  const p = Number(x.toPrecision(4));
  return p;
}

function flattenAdd(e: Expr): Expr[] {
  if (e.t === "b" && e.op === "+") return [...flattenAdd(e.l), ...flattenAdd(e.r)];
  if (e.t === "b" && e.op === "-") {
    return [...flattenAdd(e.l), ...flattenAdd(negTerm(e.r))];
  }
  return [e];
}

function negTerm(e: Expr): Expr {
  if (e.t === "c") return { t: "c", v: -e.v };
  return { t: "b", op: "*", l: { t: "c", v: -1 }, r: e };
}

function matchALog(term: Expr): { name: string; i: number; exp: number } | null {
  // a * log(x)   encoded as var name `log(x)` times const, or just `log(x)`
  if (term.t === "v" && term.n.startsWith("log(") && term.n.endsWith(")")) {
    return { name: term.n.slice(4, -1), i: term.i, exp: 1 };
  }
  if (term.t === "b" && term.op === "*") {
    const a = term.l;
    const b = term.r;
    if (a.t === "c" && b.t === "v" && b.n.startsWith("log(") && b.n.endsWith(")")) {
      return { name: b.n.slice(4, -1), i: b.i, exp: a.v };
    }
    if (b.t === "c" && a.t === "v" && a.n.startsWith("log(") && a.n.endsWith(")")) {
      return { name: a.n.slice(4, -1), i: a.i, exp: b.v };
    }
  }
  return null;
}

export function prettyPowerProduct(e: Expr, sig = 4): string | null {
  // c * x^{a} * y^{b} encoded as product of c and vars with ^{} in the name
  const factors = flattenMul(e);
  const parts: string[] = [];
  for (const f of factors) {
    if (f.t === "c") {
      if (Math.abs(f.v - 1) < 1e-12) continue;
      parts.push(formatSig(f.v, sig));
    } else if (f.t === "v") {
      parts.push(f.n);
    } else {
      return null;
    }
  }
  if (parts.length === 0) return "1";
  return parts.join(" · ");
}

function flattenMul(e: Expr): Expr[] {
  if (e.t === "b" && e.op === "*") return [...flattenMul(e.l), ...flattenMul(e.r)];
  return [e];
}

function formatSig(v: number, sig: number): string {
  if (!Number.isFinite(v)) return "NaN";
  const a = Math.abs(v);
  if (a !== 0 && (a >= 1e4 || a < 1e-3)) return v.toExponential(sig - 1);
  return String(Number(v.toPrecision(sig)));
}
