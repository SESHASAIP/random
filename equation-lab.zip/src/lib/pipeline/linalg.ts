/** Small dense linear algebra for OLS / ridge. */

export function transpose(A: number[][]): number[][] {
  const n = A.length;
  const p = A[0]?.length ?? 0;
  const T: number[][] = Array.from({ length: p }, () => Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    const row = A[i]!;
    for (let j = 0; j < p; j++) T[j]![i] = row[j]!;
  }
  return T;
}

export function matVec(A: number[][], x: number[]): number[] {
  const n = A.length;
  const out = Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    const row = A[i]!;
    let s = 0;
    for (let j = 0; j < row.length; j++) s += row[j]! * x[j]!;
    out[i] = s;
  }
  return out;
}

export function solve(Ain: number[][], bIn: number[]): number[] | null {
  const n = Ain.length;
  if (n === 0) return [];
  const A: number[][] = Ain.map((row, i) => [...row, bIn[i]!]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    let best = Math.abs(A[col]![col]!);
    for (let r = col + 1; r < n; r++) {
      const v = Math.abs(A[r]![col]!);
      if (v > best) {
        best = v;
        pivot = r;
      }
    }
    if (best < 1e-14) return null;
    if (pivot !== col) {
      const tmp = A[col]!;
      A[col] = A[pivot]!;
      A[pivot] = tmp;
    }
    const pv = A[col]![col]!;
    for (let j = col; j <= n; j++) A[col]![j]! /= pv;
    for (let r = 0; r < n; r++) {
      if (r === col) continue;
      const f = A[r]![col]!;
      if (f === 0) continue;
      for (let j = col; j <= n; j++) A[r]![j]! -= f * A[col]![j]!;
    }
  }
  return A.map((row) => row[n]!);
}

export function ols(X: number[][], y: number[], ridge = 1e-8): number[] | null {
  const n = X.length;
  const p = X[0]?.length ?? 0;
  if (n === 0 || p === 0) return null;
  const XtX: number[][] = Array.from({ length: p }, () => Array(p).fill(0));
  const Xty = Array(p).fill(0);
  for (let i = 0; i < n; i++) {
    const row = X[i]!;
    const yi = y[i]!;
    for (let a = 0; a < p; a++) {
      const va = row[a]!;
      Xty[a]! += va * yi;
      const dest = XtX[a]!;
      for (let b = a; b < p; b++) dest[b]! += va * row[b]!;
    }
  }
  for (let a = 0; a < p; a++) {
    for (let b = 0; b < a; b++) XtX[a]![b] = XtX[b]![a]!;
    XtX[a]![a]! += ridge;
  }
  return solve(XtX, Xty);
}

export function mean(xs: ArrayLike<number>): number {
  let s = 0;
  for (let i = 0; i < xs.length; i++) s += xs[i]!;
  return s / xs.length;
}

export function variance(xs: ArrayLike<number>): number {
  const n = xs.length;
  if (n < 2) return 0;
  const m = mean(xs);
  let s = 0;
  for (let i = 0; i < n; i++) {
    const d = xs[i]! - m;
    s += d * d;
  }
  return s / n;
}

export function stdev(xs: ArrayLike<number>): number {
  return Math.sqrt(variance(xs));
}

export function mse(pred: ArrayLike<number>, y: ArrayLike<number>): number {
  const n = y.length;
  let s = 0;
  for (let i = 0; i < n; i++) {
    const d = pred[i]! - y[i]!;
    if (!Number.isFinite(d)) return 1e12;
    s += d * d;
  }
  return s / n;
}

export function r2Score(pred: ArrayLike<number>, y: ArrayLike<number>): number {
  const v = variance(y);
  if (v < 1e-15) return 0;
  return 1 - mse(pred, y) / v;
}

export function quantile(xs: number[], q: number): number {
  if (xs.length === 0) return 0;
  const s = xs.slice().sort((a, b) => a - b);
  const idx = (s.length - 1) * q;
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  if (lo === hi) return s[lo]!;
  const t = idx - lo;
  return s[lo]! * (1 - t) + s[hi]! * t;
}

export function kurtosis(xs: ArrayLike<number>): number {
  const n = xs.length;
  if (n < 4) return 0;
  const m = mean(xs);
  let m2 = 0;
  let m4 = 0;
  for (let i = 0; i < n; i++) {
    const d = xs[i]! - m;
    const d2 = d * d;
    m2 += d2;
    m4 += d2 * d2;
  }
  m2 /= n;
  m4 /= n;
  if (m2 < 1e-18) return 0;
  return m4 / (m2 * m2) - 3;
}

export function iqr(xs: number[]): number {
  return quantile(xs, 0.75) - quantile(xs, 0.25);
}

export function coefVar(xs: number[]): number {
  const m = mean(xs);
  if (Math.abs(m) < 1e-12) return stdev(xs) < 1e-12 ? 0 : Infinity;
  return stdev(xs) / Math.abs(m);
}
