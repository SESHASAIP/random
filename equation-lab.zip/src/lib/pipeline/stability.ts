import { canonicalKey } from "./expr.ts";
import { coefVar, iqr } from "./linalg.ts";
import type { SREngine } from "./engines/base.ts";
import type { Equation, GateVerdict, PipelineConfig, StabilityResult } from "./types.ts";
import { usedFeatures } from "./expr.ts";

export function canonical(eq: Equation): { features: string[]; key: string } {
  return canonicalKey(eq.expr);
}

export async function runStability(
  makeEngine: () => SREngine,
  X: Float64Array[],
  y: Float64Array,
  names: string[],
  cfg: PipelineConfig,
  seeds: number[],
  yieldFn?: () => Promise<void>,
  onSeed?: (i: number, n: number) => void,
): Promise<StabilityResult> {
  const perSeed: StabilityResult["perSeed"] = [];
  const featureSets: string[][] = [];
  const keys: string[] = [];
  const complexities: number[] = [];
  const featureCount = new Map<string, number>();

  for (let si = 0; si < seeds.length; si++) {
    const seed = seeds[si]!;
    onSeed?.(si + 1, seeds.length);
    const engine = makeEngine();
    await engine.fit(X, y, names, seed);
    const best = engine.selectBest();
    const { features, key } = canonical(best);
    perSeed.push({
      seed,
      features,
      rawString: best.rawString,
      complexity: best.complexity,
      loss: best.loss,
    });
    featureSets.push(features);
    keys.push(key);
    complexities.push(best.complexity);
    for (const f of new Set(usedFeatures(best.expr))) {
      featureCount.set(f, (featureCount.get(f) ?? 0) + 1);
    }
    if (yieldFn) await yieldFn();
  }

  const modalFeatures = modeArray(featureSets.map((f) => f.join(","))).split(",").filter(Boolean);
  const modalKey = modeArray(keys);
  const n = seeds.length;
  const featureAgreement =
    featureSets.filter((f) => f.join(",") === modalFeatures.join(",")).length / n;
  const structureAgreement = keys.filter((k) => k === modalKey).length / n;
  const coefCv = coefficientCv(perSeed, keys, modalKey, n);

  const verdict = gate(
    featureAgreement,
    coefCv,
    cfg.stability.featureAgreementThreshold,
    cfg.stability.coefCvThreshold,
    modalFeatures.length,
  );

  const featureFrequency: Record<string, number> = {};
  for (const [f, c] of featureCount) featureFrequency[f] = c / n;

  return {
    verdict,
    featureAgreement,
    structureAgreement,
    coefCv,
    complexityIqr: iqr(complexities),
    featureFrequency,
    modalFeatures,
    perSeed,
    refuseEquation: verdict === "FAIL",
  };
}

function gate(
  featureAgreement: number,
  coefCv: number,
  faThr: number,
  cvThr: number,
  nFeatures: number,
): GateVerdict {
  if (nFeatures === 0) return "FAIL";
  if (featureAgreement >= faThr && coefCv < cvThr) return "PASS";
  if (featureAgreement >= 0.5) return "MARGINAL";
  return "FAIL";
}

function modeArray(xs: string[]): string {
  const counts = new Map<string, number>();
  for (const x of xs) counts.set(x, (counts.get(x) ?? 0) + 1);
  let best = xs[0] ?? "";
  let n = 0;
  for (const [k, v] of counts) {
    if (v > n) {
      best = k;
      n = v;
    }
  }
  return best;
}

function coefficientCv(
  perSeed: StabilityResult["perSeed"],
  keys: string[],
  modalKey: string,
  nSeeds: number,
): number {
  const matchingIdx = keys.map((k, i) => (k === modalKey ? i : -1)).filter((i) => i >= 0);
  if (matchingIdx.length < 2) return 1;
  const coefSeries: number[][] = [];
  for (const i of matchingIdx) coefSeries.push(extractNumbers(perSeed[i]!.rawString));
  const k = Math.min(...coefSeries.map((s) => s.length));
  if (k === 0) return matchingIdx.length === nSeeds ? 0 : 1;
  let maxCv = 0;
  for (let j = 0; j < k; j++) {
    const xs = coefSeries.map((s) => s[j]!).filter((v) => Number.isFinite(v));
    if (xs.length < 2) continue;
    maxCv = Math.max(maxCv, coefVar(xs));
  }
  return Number.isFinite(maxCv) ? maxCv : 1;
}

function extractNumbers(s: string): number[] {
  const out: number[] = [];
  const re = /[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) out.push(Number(m[0]));
  return out;
}
