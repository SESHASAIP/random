#!/bin/sh
set -eu
cd /workspace
JULIA_BIN="/root/.julia/environments/pyjuliapkg/pyjuliapkg/install/bin"
if [ -x "$JULIA_BIN/julia" ] || [ -f "$JULIA_BIN/julia" ]; then
  chmod +x "$JULIA_BIN/julia" 2>/dev/null || true
  find /root/.julia/environments/pyjuliapkg/pyjuliapkg/install/libexec -type f -exec chmod +x {} \; 2>/dev/null || true
  export PATH="$JULIA_BIN:$PATH"
fi
export PYTHON_JULIACALL_HANDLE_SIGNALS=yes
# :8081 is QA-only — a revive must never inherit a stale built-output preview.
node scripts/preview.mjs stop || true
if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  exit 0
fi
npm run dev >>/tmp/app-startup.log 2>&1 &
