#!/usr/bin/env python3
"""Stdin/stdout JSON worker wrapping PySRRegressor.

Commands:
  {"cmd": "probe"}
  {"cmd": "fit", "X": [...], "y": [...], "feature_names": [...], ...}
"""
from __future__ import annotations

import json
import os
import sys
import traceback

os.environ.setdefault("PYTHON_JULIACALL_HANDLE_SIGNALS", "yes")
os.environ.setdefault("JULIA_NUM_THREADS", "1")


def probe() -> dict:
    try:
        import juliacall  # noqa: F401
    except Exception as exc:  # pragma: no cover - environment dependent
        return {
            "ok": True,
            "julia": False,
            "pysr": False,
            "reason": f"juliacall import failed: {type(exc).__name__}: {exc}",
        }
    try:
        from pysr import PySRRegressor  # noqa: F401
    except Exception as exc:  # pragma: no cover
        return {
            "ok": True,
            "julia": True,
            "pysr": False,
            "reason": f"pysr import failed: {type(exc).__name__}: {exc}",
        }
    return {
        "ok": True,
        "julia": True,
        "pysr": True,
        "reason": "Julia reachable — PySRRegressor import succeeded.",
    }


def fit(payload: dict) -> dict:
    import numpy as np
    from pysr import PySRRegressor

    X = np.asarray(payload["X"], dtype=float)
    y = np.asarray(payload["y"], dtype=float).reshape(-1)
    names = list(payload["feature_names"])
    if X.ndim != 2 or X.shape[0] != y.shape[0]:
        raise ValueError(f"X shape {X.shape} incompatible with y length {y.shape[0]}")
    if len(names) != X.shape[1]:
        raise ValueError("feature_names length must match X columns")

    deterministic = bool(payload.get("deterministic", True))
    model = PySRRegressor(
        binary_operators=list(payload.get("binary_operators") or ["+", "-", "*", "/"]),
        unary_operators=list(payload.get("unary_operators") or ["exp", "square"]),
        niterations=int(payload.get("niterations") or 20),
        populations=int(payload.get("populations") or 6),
        population_size=int(payload.get("population_size") or 28),
        maxsize=int(payload.get("maxsize") or 18),
        parsimony=float(payload.get("parsimony") or 0.0028),
        elementwise_loss="loss(prediction, target) = (prediction - target)^2",
        deterministic=deterministic,
        random_state=int(payload.get("seed") or 0),
        parallelism="serial" if deterministic else "multithreading",
        progress=False,
        verbosity=0,
        temp_equation_file=True,
        delete_tempfiles=True,
        timeout_in_seconds=int(payload.get("timeout") or 90),
        model_selection="best",
        ncycles_per_iteration=int(payload.get("ncycles_per_iteration") or 550),
    )
    model.fit(X, y, variable_names=names)
    df = model.equations_
    if df is None or len(df) == 0:
        return {"ok": True, "equations": []}
    equations = []
    for _, row in df.iterrows():
        sympy_s = str(row["sympy_format"]) if "sympy_format" in df.columns else str(row["equation"])
        equations.append(
            {
                "complexity": int(row["complexity"]),
                "loss": float(row["loss"]),
                "score": float(row["score"]) if "score" in df.columns and row["score"] == row["score"] else 0.0,
                "sympy": sympy_s,
                "raw": str(row["equation"]),
            }
        )
    return {"ok": True, "equations": equations}


def main() -> int:
    try:
        raw = sys.stdin.read()
        payload = json.loads(raw) if raw.strip() else {"cmd": "probe"}
        cmd = payload.get("cmd", "fit")
        if cmd == "probe":
            out = probe()
        elif cmd == "fit":
            out = fit(payload)
        else:
            out = {"ok": False, "error": f"unknown cmd {cmd}"}
    except Exception as exc:
        out = {
            "ok": False,
            "julia": False,
            "pysr": False,
            "error": f"{type(exc).__name__}: {exc}",
            "trace": traceback.format_exc(),
        }
    sys.stdout.write(json.dumps(out))
    sys.stdout.flush()
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
