import { chromium } from "playwright";

const browser = await chromium.launch({ args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
page.setDefaultTimeout(120000);
page.on("console", (msg) => {
  if (["error", "warning"].includes(msg.type())) console.log("CONSOLE", msg.type(), msg.text());
});
page.on("pageerror", (err) => console.log("PAGE ERROR:", err.message));

await page.goto("http://127.0.0.1:8080/", { waitUntil: "networkidle" });
await page.waitForTimeout(400);

const run = page.getByRole("button", { name: /run discovery/i });
await run.click();
console.log("clicked run");

try {
  await page.waitForFunction(
    () => {
      const t = document.body.innerText;
      return (
        t.includes("Nested CV") ||
        t.includes("No usable equation") ||
        t.includes("Stopped before") ||
        t.includes("Feature agreement") ||
        (t.includes("PASS") && t.includes("Equation"))
      );
    },
    { timeout: 120000 },
  );
} catch (err) {
  console.log("WAIT FAILED", err.message);
  console.log(await page.locator("body").innerText());
  await page.screenshot({ path: "/workspace/screenshots/after-run-timeout.png", fullPage: true });
  await browser.close();
  process.exit(1);
}

const text = await page.locator("body").innerText();
console.log("--- HEAT RESULT ---");
console.log(text.slice(0, 2800));
await page.screenshot({ path: "/workspace/screenshots/after-run.png", fullPage: true });

await page.getByRole("button", { name: /pure noise/i }).click();
await page.waitForTimeout(500);
await page.getByRole("button", { name: /run discovery/i }).click();
try {
  await page.waitForFunction(
    () => {
      const t = document.body.innerText;
      return t.includes("FAIL") && (t.includes("No usable") || t.includes("Feature frequency") || t.includes("refuse"));
    },
    { timeout: 120000 },
  );
} catch (err) {
  console.log("NOISE WAIT FAILED", err.message);
  console.log(await page.locator("body").innerText());
  await page.screenshot({ path: "/workspace/screenshots/noise-timeout.png", fullPage: true });
  await browser.close();
  process.exit(1);
}
await page.screenshot({ path: "/workspace/screenshots/noise-fail.png", fullPage: true });
console.log("--- NOISE RESULT ---");
console.log((await page.locator("body").innerText()).slice(0, 2000));

await browser.close();
