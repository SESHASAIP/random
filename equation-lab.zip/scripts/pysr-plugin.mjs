import { spawn } from "node:child_process";
import { join } from "node:path";

const JULIA_BIN = "/root/.julia/environments/pyjuliapkg/pyjuliapkg/install/bin";

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function runWorker(payload, timeoutMs) {
  return new Promise((resolve) => {
    const worker = join(process.cwd(), "server/pysr/worker.py");
    const child = spawn("python3", [worker], {
      env: {
        ...process.env,
        PATH: `${JULIA_BIN}:${process.env.PATH ?? ""}`,
        PYTHON_JULIACALL_HANDLE_SIGNALS: "yes",
        JULIA_NUM_THREADS: "1",
      },
    });
    const out = [];
    const err = [];
    child.stdout.on("data", (d) => out.push(d));
    child.stderr.on("data", (d) => err.push(d));
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      resolve({
        ok: false,
        julia: false,
        pysr: false,
        error: "PySR worker timed out.",
      });
    }, timeoutMs);
    child.on("close", () => {
      clearTimeout(timer);
      const text = Buffer.concat(out).toString("utf8").trim();
      if (!text) {
        resolve({
          ok: false,
          error: Buffer.concat(err).toString("utf8").slice(-1200) || "empty worker output",
        });
        return;
      }
      try {
        resolve(JSON.parse(text));
      } catch {
        resolve({ ok: false, error: text.slice(0, 800) });
      }
    });
    child.stdin.write(JSON.stringify(payload));
    child.stdin.end();
  });
}

export function pysrPlugin() {
  return {
    name: "app-builder:pysr-worker",
    apply: "serve",
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const pathOnly = (req.url ?? "").split("?", 1)[0];
        if (pathOnly !== "/api/pysr" && pathOnly !== "/api/pysr-probe") {
          next();
          return;
        }
        if ((req.method ?? "GET").toUpperCase() === "GET" && pathOnly === "/api/pysr-probe") {
          const result = await runWorker({ cmd: "probe" }, 45_000);
          res.statusCode = 200;
          res.setHeader("content-type", "application/json");
          res.end(JSON.stringify(result));
          return;
        }
        if ((req.method ?? "POST").toUpperCase() !== "POST") {
          res.statusCode = 405;
          res.end("Method Not Allowed");
          return;
        }
        try {
          const body = await readBody(req);
          const payload = body ? JSON.parse(body) : { cmd: "probe" };
          const timeout = Math.min(240_000, Number(payload.timeout ?? 90) * 1000 + 20_000);
          const result = await runWorker(payload, timeout);
          res.statusCode = 200;
          res.setHeader("content-type", "application/json");
          res.end(JSON.stringify(result));
        } catch (err) {
          res.statusCode = 500;
          res.setHeader("content-type", "application/json");
          res.end(JSON.stringify({ ok: false, error: String(err) }));
        }
      });
    },
  };
}
