# Equation Lab — usage

Symbolic regression workbench. Given a numeric table, it searches for a short
equation for the target, then only reports a finding if several random seeds
agree.

The search engine is **PySR** (Julia) when that stack is installed, otherwise a
browser/Node **GP** fallback. Engine choice is logged. It is never silent.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:8080.

Optional PySR path (Julia + Python):

```bash
pip install pandas sympy pysr
# first import downloads Julia via juliacall and compiles SymbolicRegression.jl
python3 -c "from pysr import PySRRegressor; print('ok')"
```

The Vite plugin at `/api/pysr` shells out to `server/pysr/worker.py`. If Julia
is missing, the UI stays on GP.

Pipeline unit tests:

```bash
node --experimental-strip-types --test src/lib/pipeline/pipeline.test.ts
```

## Using the lab

1. Pick a dataset (or upload a CSV).
2. Confirm the **Target** column (last numeric column is the default).
3. Optionally type **Your expression** and Evaluate (in-sample R² only; not a finding).
4. Choose engine: **GP** (fast), **PySR** (Julia, slower), or **Auto**.
5. **Run discovery**.

### Built-in tables

| Dataset | What it is | Expected gate |
|---|---|---|
| Dittus–Boelter | `Nu = 0.023·Re^0.8·Pr^0.4`, four decoys, 5% noise | PASS / MARGINAL, recover Re and Pr |
| Additive identity | `y = 2.5·x0 + x1·x2` | engine acceptance case |
| Pure noise | Gaussian target | FAIL, no equation emitted |
| 50 rows | undersized heat table | screening hard-stop |

### CSV format

- Header row, unique names, comma-separated numbers
- Last numeric column is the default target
- ≥ 200 rows, 2–15 numeric columns
- Non-numeric columns are dropped

Example (`public/sample-heat.csv`):

```csv
Re,Pr,rough,T_amb,wall,L_over_D,Nu
18520.8,0.202412,0.0469213,309.526,358.103,14.2166,31.218
```

Your expression syntax: `+ - * / ^ **`, `exp log ln sqrt abs square`, parentheses.
Example: `0.023 * Re^0.8 * Pr^0.4`

## What a “finding” requires

| Gate | Rule |
|---|---|
| Screening | ≥200 rows, ≤15 features, continuous target |
| Transforms | invertible `identity` / `log` / `log1p` / `signed_log` |
| Stability | PASS: feature agreement ≥ 0.70 **and** coef CV < 0.15. MARGINAL: agreement ≥ 0.50. FAIL: refuse equation |
| Nested CV | reported R² is outer-fold test, not the split used to pick the equation |
| Back-transform | log-space `ln z = c + a ln x` is shown as `z = e^c · x^a` |

On FAIL the model card still writes, but **no equation**.

## Layout

```
src/lib/pipeline/          screening, transforms, GP, PySR client, stability, CV, report
src/lib/pipeline/engines/  base.ts, gp.ts, pysr.ts, select.ts
server/pysr/worker.py      PySRRegressor JSON worker
src/components/workbench.tsx
public/sample-heat.csv
```

Config schema lives in `src/lib/pipeline/config.ts` (`backend: auto | pysr | gp`).
